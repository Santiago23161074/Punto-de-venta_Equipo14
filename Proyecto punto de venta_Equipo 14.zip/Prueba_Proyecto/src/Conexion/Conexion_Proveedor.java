/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.sql.Connection;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author megan
 */
public class Conexion_Proveedor 
{
    Connection cx;
    Conexion_Base CB;
    
    public Conexion_Proveedor ()
    {
        CB = new Conexion_Base ();
    }
    
    public boolean InsertarProveedor (String Nombre, String ApellidoPaterno, String ApellidoMaterno, String Telefono, String Direccion)
    {
        cx = CB.Conectar();
        boolean resultado = false;
        try 
        {
            String consulta = "SELECT COUNT(*) FROM proveedor WHERE Nombre = ? AND Apellido_Paterno = ? AND Apellido_Materno = ?";
            PreparedStatement psCheck = cx.prepareStatement(consulta);
            psCheck.setString(1, Nombre);
            psCheck.setString(2, ApellidoPaterno);
            psCheck.setString(3, ApellidoMaterno);
            ResultSet rs = psCheck.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            rs.close();
            psCheck.close();

            if (count > 0) 
            {
                return false; // Ya existe, no insertar
            }
            String sql = "INSERT INTO proveedor (Nombre, Apellido_Paterno, Apellido_Materno, Telefono, Direccion) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = cx.prepareStatement(sql);
            preparedStatement.setString(1, Nombre);
            preparedStatement.setString(2, ApellidoPaterno);
            preparedStatement.setString(3, ApellidoMaterno);
            preparedStatement.setString(4, Telefono);
            preparedStatement.setString(5, Direccion);
            int filasAfectadas = preparedStatement.executeUpdate();
            if (filasAfectadas > 0) 
            {
                resultado = true;
            } 
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Proveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
    
    public boolean EliminarProveedor (String nombre, String apellidoPaterno, String apellidoMaterno)
    {
        cx = CB.Conectar();
        boolean resultado = false;
        String sql = "DELETE FROM proveedor WHERE Nombre = ? AND Apellido_Paterno = ? AND Apellido_Materno = ?";
        try 
        {
            PreparedStatement preparedStatement = cx.prepareStatement(sql);
            preparedStatement.setString(1, nombre);
            preparedStatement.setString(2, apellidoPaterno);
            preparedStatement.setString(3, apellidoMaterno);
            int filasAfectadas = preparedStatement.executeUpdate();
            if (filasAfectadas > 0) 
            {
                resultado = true;
            }
            preparedStatement.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Proveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
    
    public boolean ModificarProveedorPorNombre(String nombreOriginal, String nuevoNombre, String apellidoP, String apellidoM, String telefono, String direccion) 
    {
        cx = CB.Conectar();
        boolean resultado = false;
        String sql = "UPDATE proveedor SET Nombre = ?, Apellido_Paterno = ?, Apellido_Materno = ?, Telefono = ?, Direccion = ? WHERE Nombre = ?";
        try 
        {
            String consulta = "SELECT COUNT(*) FROM proveedor WHERE Nombre = ? AND Apellido_Paterno = ? AND Apellido_Materno = ? AND Nombre != ?";
            PreparedStatement psCheck = cx.prepareStatement(consulta);
            psCheck.setString(1, nuevoNombre);
            psCheck.setString(2, apellidoP);
            psCheck.setString(3, apellidoM);
            psCheck.setString(4, nombreOriginal);
            ResultSet rs = psCheck.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            rs.close();
            psCheck.close();
            if (count > 0) 
            {
                return false; // Ya existe otra persona con ese nombre completo
            }
            PreparedStatement ps = cx.prepareStatement(sql);
            ps.setString(1, nuevoNombre);
            ps.setString(2, apellidoP);
            ps.setString(3, apellidoM);
            ps.setString(4, telefono);
            ps.setString(5, direccion);
            ps.setString(6, nombreOriginal); // condición WHERE
            int filas = ps.executeUpdate();
            if (filas > 0) 
            {
                resultado = true;
            }
            ps.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Proveedor.class.getName()).log(Level.SEVERE, null, ex);
        }

        return resultado;
    }
    
    public List<String> ListarNombresProveedores() 
    {
        cx = CB.Conectar();
        List<String> nombres = new ArrayList<>();
        String sql = "SELECT nombre, apellido_paterno, apellido_materno FROM proveedor";
        try 
        {
            PreparedStatement preparedStatement = cx.prepareStatement(sql);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) 
            {
                nombres.add(rs.getString("nombre") + " " + rs.getString("apellido_paterno") + " " + rs.getString("apellido_materno"));
            }
            rs.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Proveedor.class.getName()).log(Level.SEVERE, null, ex);
        }

        return nombres;
    }
    
    public List<String[]> ListarProveedoresCompleto() 
    {
        cx = CB.Conectar();
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT Nombre, Apellido_Paterno, Apellido_Materno, Telefono, Direccion FROM proveedor";

        try 
        {
            PreparedStatement ps = cx.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) 
            {
                String[] datos = new String[5];
                datos[0] = rs.getString("Nombre");
                datos[1] = rs.getString("Apellido_Paterno");
                datos[2] = rs.getString("Apellido_Materno");
                datos[3] = rs.getString("Telefono");
                datos[4] = rs.getString("Direccion");
                lista.add(datos);
            }
            rs.close();
            ps.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Proveedor.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
}
