/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.util.Random;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

/**
 *
 * @author megan
 */
public class Validacion 
{
    public Validacion ()
    {
        
    }
    
    public static void soloLetras(JTextField textField) 
    {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() 
        {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException 
            {
                if (string != null && string.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) 
                {
                    super.insertString(fb, offset, string, attr);
                } // Si no son letras, no se inserta nada
            }
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException 
            {
                if (text == null || text.isEmpty() || text.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) 
                {
                    super.replace(fb, offset, length, text, attrs);
                } // Si no son letras, no reemplaza
            }
        });
    }
    
    public static void soloNumeros(JTextField textField) 
    {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() 
        {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException 
            {
                if (string != null && string.matches("\\d+")) 
                {
                    super.insertString(fb, offset, string, attr);
                }
            }
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException 
            {
                if (text != null || text.isEmpty() || text.matches("\\d+")) 
                {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }
    
    public static void Precio (JTextField textField) 
    {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() 
        {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException 
            {
                if (string == null) return;

                String nuevoTexto = new StringBuilder(textField.getText()).insert(offset, string).toString();
                if (esNumeroValido(nuevoTexto)) 
                {
                    super.insertString(fb, offset, string, attr);
                }
            }
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException 
            {
                if (text == null) return;
                StringBuilder textoActual = new StringBuilder(textField.getText());
                textoActual.replace(offset, offset + length, text);
                if (esNumeroValido(textoActual.toString())) 
                {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
            private boolean esNumeroValido(String texto) 
            {
                return texto.matches("\\d*\\.?\\d*") && texto.chars().filter(c -> c == '.').count() <= 1;
            }
        });
    }

    
    public static void soloLetrasYNumeros(JTextField textField) 
    {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() 
        {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException 
            {
                if (string != null && string.matches("[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]+")) 
                {
                    super.insertString(fb, offset, string, attr);
                }
            }
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException 
            {
                if (text != null && text.matches("[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]+")) 
                {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }
    
    public boolean VerificarCorreo (String Email)
    {
        String email = Email.toLowerCase();
        String regex = "^[\\w.-]+@[\\w.-]+\\.(com|mx|itoaxaca)$";
        boolean Verificacion = email.matches(".*@(hotmail|gmail|outlook)\\..*");
        return email.matches(regex) || Verificacion;
    }
    
    public String GenerarCodigos() 
    {
        // Letras (sin I ni O para evitar confusión), números y caracteres especiales extendidos
        String characteres = "0123456789ABCDEFGHJKLMNPQRSTUVWXYZ!@#$%&*()-_=+[]{}|;:,.<>?/";
        StringBuilder CaptchaGenerado = new StringBuilder();
        Random rand = new Random();
        for (int x = 0; x < 8; x++) 
        {
            CaptchaGenerado.append(characteres.charAt(rand.nextInt(characteres.length())));
        }
        return CaptchaGenerado.toString();
    }
}
