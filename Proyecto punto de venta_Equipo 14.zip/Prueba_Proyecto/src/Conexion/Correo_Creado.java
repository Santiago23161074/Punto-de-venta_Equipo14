/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;
import com.itextpdf.text.Image;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author megan
 */


public class Correo_Creado 
{
    // contra wlgl xcum nquk cyoe
    private final String CorreoRemitente = "mercad.ito.tap14@gmail.com";
    private final String ContraseñaRemitente = "dior zlmu gcch kxrh";
    private String rutaPDF;
    private final String NombreEmpresa = "Mercad - ITO";
    private final String rutaLOGO = "C:/Users/megan/OneDrive/Documentos/ITO/4 SEMESTRE/Topicos Avanzados de Programacion/Proyecto_Final_Equipo14/src/Img/ito.PNG";
    
    public Correo_Creado ()
    {
       
    }
    
    public String generarRutaPDF(String tipo, String identificador) 
    {
        String carpetaDestino = "C:/Users/megan/OneDrive/Documentos/ITO/4 SEMESTRE/CrearPDF/";
        String timestamp = java.time.LocalDateTime.now().toString().replace(":", "-").replace("T", "_").substring(0, 16); // YYYY-MM-DD_HH-MM
        String nombreArchivo = (identificador == null || identificador.isEmpty())
        ? tipo + "_" + timestamp + ".pdf"
        : tipo + "_" + identificador + "_" + timestamp + ".pdf";
        rutaPDF = carpetaDestino + nombreArchivo;
        return rutaPDF;
    }
    
    public void CrearPDFVenta(List<String[]> lista, String nombreUsuario, String telefono, String direccion, String nombreCajero, String apellidoPaterno, String apellidoMaterno) 
    {
        try 
        {
            Document doc = new Document();
            PdfWriter.getInstance(doc, new FileOutputStream(rutaPDF));
            doc.open();
            // 1. Encabezado con logo y nombre empresa
            PdfPTable encabezado = new PdfPTable(2);
            encabezado.setWidthPercentage(100);
            encabezado.setWidths(new float[]{1, 3});
            Image logo = Image.getInstance(rutaLOGO);
            logo.scaleToFit(100, 100);
            PdfPCell celdaLogo = new PdfPCell(logo);
            celdaLogo.setBorder(Rectangle.NO_BORDER);
            celdaLogo.setHorizontalAlignment(Element.ALIGN_CENTER);
            encabezado.addCell(celdaLogo);
            Font fuenteEmpresa = new Font(Font.FontFamily.TIMES_ROMAN, 20, Font.BOLD, BaseColor.DARK_GRAY);
            PdfPCell celdaNombreEmpresa = new PdfPCell(new Phrase(NombreEmpresa, fuenteEmpresa));
            celdaNombreEmpresa.setBorder(Rectangle.NO_BORDER);
            celdaNombreEmpresa.setHorizontalAlignment(Element.ALIGN_CENTER);
            celdaNombreEmpresa.setVerticalAlignment(Element.ALIGN_MIDDLE);
            encabezado.addCell(celdaNombreEmpresa);
            doc.add(encabezado);
            doc.add(Chunk.NEWLINE);
            // 2. Título
            Paragraph titulo = new Paragraph("Productos Vendidos", new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD));
            titulo.setAlignment(Element.ALIGN_CENTER);
            doc.add(titulo);
            doc.add(Chunk.NEWLINE);
            // 3. Tabla de productos
            PdfPTable tabla = new PdfPTable(4); // Producto, Cantidad, Precio Unitario, Total
            tabla.setWidthPercentage(100);
            tabla.setWidths(new float[]{4, 2, 2, 2});
            BaseColor grisClaro = new BaseColor(230, 230, 230);
            Font fuenteEncabezado = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
            tabla.addCell(celda("Producto", Element.ALIGN_CENTER, fuenteEncabezado, grisClaro, false));
            tabla.addCell(celda("Cantidad", Element.ALIGN_CENTER, fuenteEncabezado, grisClaro, false));
            tabla.addCell(celda("Precio Unitario", Element.ALIGN_CENTER, fuenteEncabezado, grisClaro, false));
            tabla.addCell(celda("Total", Element.ALIGN_CENTER, fuenteEncabezado, grisClaro, false));
            double totalVenta = 0.0;
            Font fuenteContenido = new Font(Font.FontFamily.HELVETICA, 11);
            for (String[] producto : lista) 
            {
                tabla.addCell(celda(producto[0], Element.ALIGN_LEFT, fuenteContenido, BaseColor.WHITE, true));
                tabla.addCell(celda(producto[2], Element.ALIGN_CENTER, fuenteContenido, BaseColor.WHITE, true));
                tabla.addCell(celda("$" + producto[3], Element.ALIGN_RIGHT, fuenteContenido, BaseColor.WHITE, true));
                tabla.addCell(celda("$" + producto[4], Element.ALIGN_RIGHT, fuenteContenido, BaseColor.WHITE, true));
                totalVenta += Double.parseDouble(producto[4]);
            }
            doc.add(tabla);
            doc.add(Chunk.NEWLINE);
            // 4. Total final
            PdfPTable total = new PdfPTable(1);
            total.setWidthPercentage(50);
            total.setHorizontalAlignment(Element.ALIGN_CENTER);
            total.addCell(celda("TOTAL: $" + String.format("%.2f", totalVenta), Element.ALIGN_CENTER, fuenteEncabezado, grisClaro, false));
            doc.add(total);
            doc.add(Chunk.NEWLINE);
            // 5. Pie de página con datos del usuario y cajero
            PdfPTable pie = new PdfPTable(2);
            pie.setWidthPercentage(100);
            pie.setWidths(new float[]{1, 2});
            pie.addCell(celda("Fecha: " + java.time.LocalDate.now(), Element.ALIGN_CENTER, fuenteContenido, BaseColor.WHITE, false));
            // Información formateada
            String infoUsuario = 
                "Cliente:\n" +
                "Nombre: " + nombreUsuario + "\n" +
                "Tel: " + telefono + "\n" +
                "Dirección: " + direccion + "\n\n" +
                "Cajero:\n" +
                nombreCajero + " " + apellidoPaterno + " " + apellidoMaterno;
            PdfPCell celdaUsuario = celda(infoUsuario, Element.ALIGN_LEFT, fuenteContenido, BaseColor.WHITE, false);
            celdaUsuario.setPadding(5);
            pie.addCell(celdaUsuario);
            doc.add(pie);
            doc.close();
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }

    private PdfPCell celda(String texto, int alineacion, Font fuente, BaseColor fondo, boolean conBorde) 
    {
        PdfPCell celda = new PdfPCell(new Phrase(texto, fuente));
        celda.setHorizontalAlignment(alineacion);
        celda.setVerticalAlignment(Element.ALIGN_MIDDLE);
        celda.setBackgroundColor(fondo);
        celda.setPadding(5);
        if (!conBorde) 
        {
            celda.setBorder(Rectangle.NO_BORDER);
        }
        return celda;
    }
    
    //listo
    public void crearPDFRecuperacion(String nombreCompleto, String correoUsuario, String cargoUsuario, String codigoVerificacion) 
    {
        try 
        {
            Document doc = new Document();
            PdfWriter.getInstance(doc, new FileOutputStream(rutaPDF));
            doc.open();
            // Fuente moderna y seria
            Font fuenteTituloEmpresa = new Font(Font.FontFamily.HELVETICA, 22, Font.BOLD, BaseColor.DARK_GRAY);
            Font fuenteSubtitulo = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.BLACK);
            Font fuenteTexto = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.DARK_GRAY);
            Font fuenteCodigo = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, new BaseColor(30, 30, 30));
            Font fuentePie = new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.GRAY);
            // 1. Encabezado con logo y nombre de empresa
            PdfPTable encabezado = new PdfPTable(2);
            encabezado.setWidthPercentage(100);
            encabezado.setWidths(new float[]{1, 3});
            Image logo = Image.getInstance(rutaLOGO);
            logo.scaleToFit(80, 80);
            PdfPCell celdaLogo = new PdfPCell(logo);
            celdaLogo.setBorder(Rectangle.NO_BORDER);
            celdaLogo.setHorizontalAlignment(Element.ALIGN_LEFT);
            celdaLogo.setVerticalAlignment(Element.ALIGN_MIDDLE);
            encabezado.addCell(celdaLogo);
            PdfPCell celdaNombreEmpresa = new PdfPCell(new Phrase(NombreEmpresa, fuenteTituloEmpresa));
            celdaNombreEmpresa.setBorder(Rectangle.NO_BORDER);
            celdaNombreEmpresa.setHorizontalAlignment(Element.ALIGN_LEFT);
            celdaNombreEmpresa.setVerticalAlignment(Element.ALIGN_MIDDLE);
            encabezado.addCell(celdaNombreEmpresa);
            doc.add(encabezado);
            doc.add(Chunk.NEWLINE);
            // 2. Título del documento
            Paragraph titulo = new Paragraph("Código de Recuperación de Cuenta", fuenteSubtitulo);
            titulo.setAlignment(Element.ALIGN_CENTER);
            titulo.setSpacingBefore(20);
            titulo.setSpacingAfter(20);
            doc.add(titulo);
            // 3. Tabla de datos del usuario
            PdfPTable tabla = new PdfPTable(1);
            tabla.setWidthPercentage(90);
            tabla.setSpacingAfter(10);
            tabla.addCell(celdaTexto("Nombre completo: " + nombreCompleto, fuenteTexto));
            tabla.addCell(celdaTexto("Correo electrónico: " + correoUsuario, fuenteTexto));
            tabla.addCell(celdaTexto("Cargo: " + cargoUsuario, fuenteTexto));
            PdfPCell celdaCodigo = celdaTexto("Código de verificación: " + codigoVerificacion, fuenteCodigo);
            celdaCodigo.setPaddingTop(15);
            celdaCodigo.setPaddingBottom(15);
            celdaCodigo.setHorizontalAlignment(Element.ALIGN_CENTER);
            celdaCodigo.setBackgroundColor(new BaseColor(230, 230, 230));
            tabla.addCell(celdaCodigo);
            doc.add(tabla);
            // 4. Pie de página con la fecha de emisión
            PdfPTable pie = new PdfPTable(1);
            pie.setWidthPercentage(100);
            pie.setSpacingBefore(40);
            PdfPCell celdaFecha = celdaTexto("Fecha de emisión: " + java.time.LocalDate.now(), fuentePie);
            celdaFecha.setHorizontalAlignment(Element.ALIGN_CENTER);
            celdaFecha.setBorder(Rectangle.NO_BORDER);
            pie.addCell(celdaFecha);
            doc.add(pie);
            doc.close();
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
       
    private PdfPCell celdaTexto(String texto, Font fuente) 
    {
        PdfPCell celda = new PdfPCell(new Phrase(texto, fuente));
        celda.setPadding(8);
        celda.setBorder(Rectangle.NO_BORDER);
        return celda;
    }
    //listo
    public void crearPDFVerificacion(String CodigoVerificacion, String nombrePersona, String correoPersona) 
    {
        try 
        {
            Document documento = new Document();
            PdfWriter.getInstance(documento, new FileOutputStream(rutaPDF));
            documento.open();
            // Fuente del nombre de la empresa
            Font fuenteNombreEmpresa = new Font(Font.FontFamily.TIMES_ROMAN, 20, Font.BOLD, BaseColor.DARK_GRAY);
            // Tabla principal con logo y nombre
            PdfPTable tablaPrincipal = new PdfPTable(2);
            tablaPrincipal.setWidthPercentage(100);
            tablaPrincipal.setWidths(new float[]{2, 4});
            // Logo
            Image logo = Image.getInstance(rutaLOGO);
            logo.scaleToFit(100, 100);
            PdfPCell celdaLogo = new PdfPCell(logo);
            celdaLogo.setBorder(Rectangle.NO_BORDER);
            celdaLogo.setRowspan(2);
            celdaLogo.setVerticalAlignment(Element.ALIGN_MIDDLE);
            tablaPrincipal.addCell(celdaLogo);
            // Nombre de la empresa
            PdfPCell celdaEmpresa = new PdfPCell(new Phrase(NombreEmpresa, fuenteNombreEmpresa));
            celdaEmpresa.setHorizontalAlignment(Element.ALIGN_CENTER);
            celdaEmpresa.setVerticalAlignment(Element.ALIGN_MIDDLE);
            celdaEmpresa.setBorder(Rectangle.NO_BORDER);
            tablaPrincipal.addCell(celdaEmpresa);
            tablaPrincipal.setSpacingBefore(35);
            documento.add(tablaPrincipal);
            documento.add(Chunk.NEWLINE);
            // Texto informativo
            Font fuenteTexto = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL, BaseColor.BLACK);
            Font fuenteCodigo = new Font(Font.FontFamily.TIMES_ROMAN, 16, Font.BOLD, BaseColor.BLACK);
            PdfPTable tablaInfo = new PdfPTable(1);
            tablaInfo.setWidthPercentage(80);
            tablaInfo.setSpacingBefore(25);
            tablaInfo.setSpacingAfter(15);
            PdfPCell celdaMensaje = celdaTexto("Por favor ingresa el siguiente código en el campo correspondiente:", fuenteTexto);
            celdaMensaje.setHorizontalAlignment(Element.ALIGN_CENTER);
            tablaInfo.addCell(celdaMensaje);
            PdfPCell celdaCodigo = celdaTexto(CodigoVerificacion, fuenteCodigo);
            celdaCodigo.setHorizontalAlignment(Element.ALIGN_CENTER);
            celdaCodigo.setPaddingTop(10);
            celdaCodigo.setPaddingBottom(10);
            tablaInfo.addCell(celdaCodigo);
            documento.add(tablaInfo);
            // Datos del usuario
            PdfPTable tablaUsuario = new PdfPTable(1);
            tablaUsuario.setWidthPercentage(80);
            tablaUsuario.setSpacingBefore(10);
            tablaUsuario.setSpacingAfter(15);
            Font fuenteDato = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL, BaseColor.DARK_GRAY);
            PdfPCell celdaNombre = celdaTexto("Nombre: " + nombrePersona, fuenteDato);
            celdaNombre.setHorizontalAlignment(Element.ALIGN_CENTER);
            tablaUsuario.addCell(celdaNombre);
            PdfPCell celdaCorreo = celdaTexto("Correo electrónico: " + correoPersona, fuenteDato);
            celdaCorreo.setHorizontalAlignment(Element.ALIGN_CENTER);
            tablaUsuario.addCell(celdaCorreo);
            documento.add(tablaUsuario);
            // Fecha
            PdfPTable tablaFecha = new PdfPTable(1);
            tablaFecha.setWidthPercentage(70);
            tablaFecha.setSpacingBefore(70);
            LocalDateTime ahora = LocalDateTime.now();
            DateTimeFormatter formatoFechaHora = DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy HH:mm:ss");
            String fechaHoraFormateada = ahora.format(formatoFechaHora);
            Font fuenteFecha = new Font(Font.FontFamily.TIMES_ROMAN, 11, Font.NORMAL, BaseColor.GRAY);
            PdfPCell celdaFecha = celdaTexto("Fecha: " + fechaHoraFormateada, fuenteFecha);
            celdaFecha.setHorizontalAlignment(Element.ALIGN_CENTER);
            tablaFecha.addCell(celdaFecha);
            documento.add(tablaFecha);
            documento.close();
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
    
    public void EnviarCorreo (String CorreoDestinatario, String Cuerpo) throws MessagingException
    {
        Properties propiedades = new Properties();
        propiedades.put("mail.smtp.host", "smtp.gmail.com");
        propiedades.put("mail.smtp.port", "587");
        propiedades.put("mail.smtp.auth", "true");
        propiedades.put("mail.smtp.starttls.enable", "true");
        propiedades.put("mail.smtp.ssl.protocols", "TLSv1.2");
        Session sesion = Session.getInstance(propiedades, new Authenticator() 
        {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() 
            {
                return new PasswordAuthentication(CorreoRemitente, ContraseñaRemitente);
            }
        });
        try 
        {
            Message mensaje = new MimeMessage(sesion);
            mensaje.setFrom(new InternetAddress(CorreoRemitente));
            mensaje.setRecipient(Message.RecipientType.TO, new InternetAddress(CorreoDestinatario));
            mensaje.setSubject(Cuerpo);
            MimeBodyPart adjunto = new MimeBodyPart();
            File archivo = new File(rutaPDF);
            adjunto.attachFile(archivo);
            Multipart contenido = new MimeMultipart();
            contenido.addBodyPart(adjunto);
            mensaje.setContent(contenido);
            Transport.send(mensaje);
            JOptionPane.showMessageDialog(null, "Correo enviado correctamente");
        } 
        catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null, "Correo electronico no encontrado");
        }
    }
    
    public static void main (String args []) throws MessagingException
    {
        Correo_Creado prueba = new Correo_Creado();
        prueba.generarRutaPDF("Prueba", null);
        prueba.crearPDFVerificacion("Me la pelas ","angel","prueba");
        prueba.EnviarCorreo("meganegro29@gmail.com","hola");
    }
}
