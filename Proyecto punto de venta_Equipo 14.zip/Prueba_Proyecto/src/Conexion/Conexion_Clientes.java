/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

/**
 *
 * @author megan
 */

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Conexion_Clientes 
{
    Connection cx;
    Conexion_Base CB;
    
    public Conexion_Clientes ()
    {
        CB = new Conexion_Base();
    }
    
    public List<String []> ListarClientes()
    {
        cx = CB.Conectar();
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT Nombre, ApellidoPaterno, ApellidoMaterno, Telefono, Correo, Direccion FROM clientes";
        try 
        {
            PreparedStatement ps = cx.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String[] fila = new String[6];
                fila[0] = rs.getString("Nombre");
                fila[1] = rs.getString("ApellidoPaterno");
                fila[2] = rs.getString("ApellidoMaterno");
                fila[3] = rs.getString("Telefono");
                fila[4] = rs.getString("Correo");
                fila[5] = rs.getString("Direccion");
                lista.add(fila);
            }
            rs.close();
            ps.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Personal.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }
    
    public List<String> ListarClientesCorreo()
    {
        cx = CB.Conectar();
        List<String> lista = new ArrayList<>();
        String sql = "SELECT Correo FROM clientes";
        try 
        {
            PreparedStatement ps = cx.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) 
            {
                lista.add(rs.getString("Correo"));
            }
            rs.close();
            ps.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Proveedor.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
    
    public boolean InsertarCliente (String Nombre, String ApellidoPaterno, String ApellidoMaterno, String Telefono, String Correo, String Direccion)
    {
        cx = CB.Conectar();
        boolean resultado = false;
        try 
        {
            String consulta = "SELECT COUNT(*) FROM clientes WHERE Nombre = ? AND ApellidoPaterno = ? AND ApellidoMaterno = ?";
            PreparedStatement psCheck = cx.prepareStatement(consulta);
            psCheck.setString(1, Nombre);
            psCheck.setString(2, ApellidoPaterno);
            psCheck.setString(3, ApellidoMaterno);
            ResultSet rs = psCheck.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            rs.close();
            psCheck.close();

            if (count > 0) 
            {
                return false; // Ya existe, no insertar
            }
            String sql = "INSERT INTO clientes (Nombre, ApellidoPaterno, ApellidoMaterno, Telefono, Correo, Direccion) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = cx.prepareStatement(sql);
            preparedStatement.setString(1, Nombre);
            preparedStatement.setString(2, ApellidoPaterno);
            preparedStatement.setString(3, ApellidoMaterno);
            preparedStatement.setString(4, Telefono);
            preparedStatement.setString(5, Correo);
            preparedStatement.setString(6, Direccion);
            int filasAfectadas = preparedStatement.executeUpdate();
            if (filasAfectadas > 0) 
            {
                resultado = true;
            } 
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Clientes.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
    
    public boolean EliminarCliente(String nombre, String apellidoPaterno, String apellidoMaterno) 
    {
        cx = CB.Conectar();
        boolean resultado = false;
        String sql = "DELETE FROM clientes WHERE Nombre = ? AND ApellidoPaterno = ? AND ApellidoMaterno = ?";
        try 
        {
            PreparedStatement preparedStatement = cx.prepareStatement(sql);
            preparedStatement.setString(1, nombre);
            preparedStatement.setString(2, apellidoPaterno);
            preparedStatement.setString(3, apellidoMaterno);
            int filasAfectadas = preparedStatement.executeUpdate();
            if (filasAfectadas > 0) 
            {
                resultado = true;
            }
            preparedStatement.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Clientes.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
    
    public boolean ModificarCliente(String nombreOriginal, String apellidoPOriginal, String apellidoMOriginal, String nuevoNombre, String nuevoApellidoP, String nuevoApellidoM, String telefono, String correo, String direccion) 
    {
        cx = CB.Conectar();
        boolean resultado = false;
        try 
        {
            // Verificar que no exista otro cliente con el mismo nuevo nombre completo
            String consultaDuplicado = "SELECT COUNT(*) FROM clientes WHERE Nombre = ? AND ApellidoPaterno = ? AND ApellidoMaterno = ? AND NOT (Nombre = ? AND ApellidoPaterno = ? AND ApellidoMaterno = ?)";
            PreparedStatement psCheck = cx.prepareStatement(consultaDuplicado);
            psCheck.setString(1, nuevoNombre);
            psCheck.setString(2, nuevoApellidoP);
            psCheck.setString(3, nuevoApellidoM);
            psCheck.setString(4, nombreOriginal);
            psCheck.setString(5, apellidoPOriginal);
            psCheck.setString(6, apellidoMOriginal);
            ResultSet rs = psCheck.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            rs.close();
            psCheck.close();
            if (count > 0) 
            {
                // Ya existe otro cliente con el mismo nombre completo
                return false;
            }
            // Actualizar los datos del cliente
            String sqlActualizar = "UPDATE clientes SET Nombre = ?, ApellidoPaterno = ?, ApellidoMaterno = ?, Telefono = ?, Correo = ?, Direccion = ? WHERE Nombre = ? AND ApellidoPaterno = ? AND ApellidoMaterno = ?";
            PreparedStatement psActualizar = cx.prepareStatement(sqlActualizar);
            psActualizar.setString(1, nuevoNombre);
            psActualizar.setString(2, nuevoApellidoP);
            psActualizar.setString(3, nuevoApellidoM);
            psActualizar.setString(4, telefono);
            psActualizar.setString(5, correo);
            psActualizar.setString(6, direccion);
            psActualizar.setString(7, nombreOriginal);
            psActualizar.setString(8, apellidoPOriginal);
            psActualizar.setString(9, apellidoMOriginal);
            int filas = psActualizar.executeUpdate();
            if (filas > 0) 
            {
                resultado = true;
            }
            psActualizar.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Clientes.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
    
    public String [] DatosCliente (String Correo)
    {
        cx = CB.Conectar();
        String [] DatosCliente = new String [5];
        String sql = " SELECT Nombre, ApellidoPaterno, ApellidoMaterno, Telefono, Direccion FROM clientes WHERE Correo = ?";
        try 
        {
            PreparedStatement ps = cx.prepareStatement(sql);
            ps.setString(1,Correo);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) 
            {
                DatosCliente [0] = rs.getString("Nombre");
                DatosCliente [1] = rs.getString("ApellidoPaterno");
                DatosCliente [2] = rs.getString("ApellidoMaterno");
                DatosCliente [3] = rs.getString("Telefono");
                DatosCliente [4] = rs.getString("Direccion");
            }
            rs.close();
            ps.close();
        }
        catch (SQLException ex)
        {
            
        }      
        return DatosCliente;
    }
}
