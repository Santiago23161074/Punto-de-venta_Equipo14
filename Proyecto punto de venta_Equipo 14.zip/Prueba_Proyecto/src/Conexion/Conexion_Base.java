/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author megan
 */
public class Conexion_Base 
{
    String bd = "proyecto_tap_14";
    String url = "jdbc:mysql://127.0.0.1:3306/";
    String user = "root";
    String password = "AngelMEGA290105";
    String driver = "com.mysql.cj.jdbc.Driver";
    Connection cx;
    
    public Conexion_Base ()
    {
        
    }
    
    public Connection Conectar ()
    {
        try 
        {
            Class.forName(driver);
            cx = DriverManager.getConnection (url+bd,user,password);
        } 
        catch (ClassNotFoundException |SQLException ex) 
        {
            Logger.getLogger(Conexion_Clientes.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cx;
    }
    
    public void Desconectar ()
    {
        try 
        {
            cx.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Clientes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main (String args[])
    {
        Conexion_Base CB = new Conexion_Base ();
        CB.Conectar();
    }
}
