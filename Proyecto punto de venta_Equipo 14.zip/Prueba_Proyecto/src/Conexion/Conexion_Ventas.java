/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

/**
 *
 * @author megan
 */
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Statement;

public class Conexion_Ventas 
{
    Connection cx;
    Conexion_Base CB;
    Correo_Creado CC;
    
    public Conexion_Ventas()
    {
        CB = new Conexion_Base ();
        CC = new Correo_Creado ();
    }
    
    public boolean EliminarVenta (int idVenta) 
    {
        cx = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String obtenerDetalles = "SELECT id_producto, cantidad FROM detalleventa WHERE id_venta = ?";
        String actualizarStock = "UPDATE producto SET cantidad = cantidad + ? WHERE id = ?";
        String eliminarDetalle = "DELETE FROM detalleventa WHERE id_venta = ?";
        String eliminarVenta = "DELETE FROM ventas WHERE id_venta = ?";
        try 
        {
            cx = CB.Conectar();
            cx.setAutoCommit(false); // Iniciar transacción
            // 1. Obtener productos y cantidades de la venta
            ps = cx.prepareStatement(obtenerDetalles);
            ps.setInt(1, idVenta);
            rs = ps.executeQuery();
            List<int[]> productos = new ArrayList<>();
            while (rs.next()) 
            {
                int idProducto = rs.getInt("id_producto");
                int cantidad = rs.getInt("cantidad");
                productos.add(new int[]{idProducto, cantidad});
            }
            rs.close();
            ps.close();
            // 2. Actualizar el stock por cada producto
            ps = cx.prepareStatement(actualizarStock);
            for (int[] producto : productos) 
            {
                ps.setInt(1, producto[1]); // cantidad
                ps.setInt(2, producto[0]); // id_producto
                ps.addBatch();
            }
            ps.executeBatch();
            ps.close();
            // 3. Eliminar de detalleventa
            ps = cx.prepareStatement(eliminarDetalle);
            ps.setInt(1, idVenta);
            ps.executeUpdate();
            ps.close();
            // 4. Eliminar de ventas
            ps = cx.prepareStatement(eliminarVenta);
            ps.setInt(1, idVenta);
            ps.executeUpdate();
            ps.close();
            cx.commit(); // Confirmar la transacción
            return true;
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
            if (cx != null) 
            {
                try 
                {
                    cx.rollback(); // Revertir todo si algo falla
                } 
                catch (SQLException rollbackEx) 
                {
                    rollbackEx.printStackTrace();
                }
            }
            return false;
        } 
        finally 
        {
            try 
            {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (cx != null) cx.setAutoCommit(true); // Restaurar auto-commit
            } 
            catch (SQLException e) 
            {
                e.printStackTrace();
            }
        }
    }
    
    public boolean registrarVenta(String correoCliente, String usuarioCajero, List<String[]> ticket)
    {
        // Ensure CB is your database connection utility
        cx = CB.Conectar(); // This line was in your original code
        String insertVentaSQL = "INSERT INTO ventas (correo_cliente, usuario_cajero, total, fecha_venta) VALUES (?, ?, ?, NOW())";
        String selectProductoIdSQL = "SELECT id FROM producto WHERE codigo = ?"; // Only need id
        String insertDetalleSQL = "INSERT INTO detalleventa (id_venta, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
        PreparedStatement psVenta = null;
        PreparedStatement psSelectProducto = null;
        PreparedStatement psDetalle = null;
        ResultSet rsVentaId = null;
        ResultSet rsProductoId = null;
        try
        {
            cx.setAutoCommit(false); // Start transaction
            // Calculate total sum of the sale
            double totalCompra = 0.0;
            for (String[] producto : ticket)
            {
                double totalProducto = Double.parseDouble(producto[4]);
                totalCompra += totalProducto;
            }

            // 1. Insert into 'ventas' table
            psVenta = cx.prepareStatement(insertVentaSQL, Statement.RETURN_GENERATED_KEYS);
            psVenta.setString(1, correoCliente);
            psVenta.setString(2, usuarioCajero);
            psVenta.setDouble(3, totalCompra);
            psVenta.executeUpdate();

            rsVentaId = psVenta.getGeneratedKeys();
            int idVenta = -1;
            if (rsVentaId.next())
            {
                idVenta = rsVentaId.getInt(1);
            }
            else
            {
                cx.rollback();
                System.err.println("Error: No se pudo obtener el ID de la venta generada.");
                return false;
            }

            // 2. Prepare statements for 'detalle_venta'
            psSelectProducto = cx.prepareStatement(selectProductoIdSQL);
            psDetalle = cx.prepareStatement(insertDetalleSQL);

            // 3. Process each product in the ticket for 'detalle_venta'
            for (String[] producto : ticket)
            {
                int codigo = Integer.parseInt(producto[1]);
                int cantidad = Integer.parseInt(producto[2]);
                double precioUnitario = Double.parseDouble(producto[3]);

                // Get product ID based on code
                psSelectProducto.setInt(1, codigo);
                rsProductoId = psSelectProducto.executeQuery();

                if (rsProductoId.next())
                {
                    int idProducto = rsProductoId.getInt("id");

                    // Add to batch for 'detalle_venta'
                    psDetalle.setInt(1, idVenta);
                    psDetalle.setInt(2, idProducto);
                    psDetalle.setInt(3, cantidad);
                    psDetalle.setDouble(4, precioUnitario);
                    psDetalle.addBatch();
                }
                else
                {
                    cx.rollback();
                    System.err.println("Error: Producto con código " + codigo + " no encontrado. Se cancela la venta.");
                    return false;
                }
            }

            // Execute all batched statements for detalle_venta
            psDetalle.executeBatch();

            cx.commit(); // Commit the transaction
            return true;
        }
        catch (Exception ex)
        {
            try
            {
                if (cx != null) cx.rollback(); // Rollback on any exception
            }
            catch (SQLException rollbackEx)
            {
                rollbackEx.printStackTrace();
            }
            ex.printStackTrace();
            return false;
        }
        finally
        {
            // Close all resources in the finally block
            try
            {
                if (rsProductoId != null) rsProductoId.close();
                if (rsVentaId != null) rsVentaId.close();
                if (psVenta != null) psVenta.close();
                if (psSelectProducto != null) psSelectProducto.close();
                if (psDetalle != null) psDetalle.close();
                if (cx != null) cx.setAutoCommit(true); // Reset auto-commit to true
                // It's good practice to close the connection here if it was opened within this method,
                // or ensure it's closed by your connection pool/manager.
                // if (cx != null) cx.close(); // Uncomment if connection is managed locally
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }
    
    public List<String[]> obtenerReporteVentas() 
    {
        List<String[]> salesData = new ArrayList<>();
        // SQL Query to join ventas, clientes, and personal tables
        String sql = "SELECT " +
                     "v.id_venta, " +
                     "CONCAT(c.Nombre, ' ', c.ApellidoPaterno, ' ', c.ApellidoMaterno) AS NombreCliente, " +
                     "CONCAT(p.nombre, ' ', p.apellido_paterno, ' ', p.apellido_materno) AS NombreCajero, " +
                     "v.total, " +
                     "v.fecha_venta " +
                     "FROM ventas v " +
                     "LEFT JOIN clientes c ON v.correo_cliente = c.Correo " +
                     "LEFT JOIN personal p ON v.usuario_cajero = p.correo " +
                     "ORDER BY v.fecha_venta DESC"; // Order by most recent sales

        PreparedStatement ps = null;
        ResultSet rs = null;
        try 
        {
            cx = CB.Conectar();
            ps = cx.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) 
            {
                String[] row = new String[5]; // 5 columns as requested
                row[0] = String.valueOf(rs.getInt("id_venta"));
                // Handle potential NULLs from LEFT JOIN for names
                row[1] = rs.getString("NombreCliente") == null ? "N/A" : rs.getString("NombreCliente");
                row[2] = rs.getString("NombreCajero") == null ? "N/A" : rs.getString("NombreCajero");
                row[3] = String.format("%.2f", rs.getDouble("total")); // Format total to 2 decimal places
                row[4] = rs.getTimestamp("fecha_venta").toString(); // Convert timestamp to String
                salesData.add(row);
            }
        } 
        catch (SQLException ex) 
        {
            System.err.println("Error al obtener ventas: " + ex.getMessage());
            ex.printStackTrace();
            return new ArrayList<>(); // Return empty list on error
        } 
        finally 
        {
            // Close resources
            try 
            {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                // Do NOT close the connection here if it's managed externally (e.g., in a connection pool)
            } 
            catch (SQLException e) 
            {
                e.printStackTrace();
            }
        }
        return salesData;
    }
    
    public void generarPDFVenta(int idVenta) 
    {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<String[]> productos = new ArrayList<>();
        String nombreCliente = "N/A", telefono = "", direccion = "";
        String nombreCajero = "", apellidoPaternoCajero = "", apellidoMaternoCajero = "";
        try 
        {
            cx = CB.Conectar();
            // 1. Obtener detalles de productos
            String sqlDetalle = "SELECT pr.nombre, dv.cantidad, dv.precio_unitario, " +
                                "(dv.cantidad * dv.precio_unitario) AS total " +
                                "FROM detalleventa dv " +
                                "JOIN producto pr ON dv.id_producto = pr.id " +
                                "WHERE dv.id_venta = ?";
            ps = cx.prepareStatement(sqlDetalle);
            ps.setInt(1, idVenta);
            rs = ps.executeQuery();
            while (rs.next()) 
            {
                String[] item = new String[5];
                item[0] = rs.getString("nombre");
                item[1] = ""; // no usado en PDF
                item[2] = String.valueOf(rs.getInt("cantidad"));
                item[3] = String.format("%.2f", rs.getDouble("precio_unitario"));
                item[4] = String.format("%.2f", rs.getDouble("total"));
                productos.add(item);
            }
            rs.close();
            ps.close();
            // 2. Obtener datos cliente y cajero
            String sqlVenta = "SELECT v.correo_cliente, v.usuario_cajero, c.Nombre, c.ApellidoPaterno, c.ApellidoMaterno, c.Telefono, c.Direccion, " +
                              "p.nombre AS nombreCajero, p.apellido_paterno, p.apellido_materno " +
                              "FROM ventas v " +
                              "LEFT JOIN clientes c ON v.correo_cliente = c.Correo " +
                              "LEFT JOIN personal p ON v.usuario_cajero = p.correo " +
                              "WHERE v.id_venta = ?";
            ps = cx.prepareStatement(sqlVenta);
            ps.setInt(1, idVenta);
            rs = ps.executeQuery();
            if (rs.next()) 
            {
                nombreCliente = rs.getString("Nombre") + " " +
                                rs.getString("ApellidoPaterno") + " " +
                                rs.getString("ApellidoMaterno");
                telefono = rs.getString("Telefono");
                direccion = rs.getString("Direccion");
                nombreCajero = rs.getString("nombreCajero");
                apellidoPaternoCajero = rs.getString("apellido_paterno");
                apellidoMaternoCajero = rs.getString("apellido_materno");
            }
            // 3. Llamar al método que crea el PDF
            CC.generarRutaPDF("Venta", String.valueOf(idVenta));
            CC.CrearPDFVenta(productos, nombreCliente, telefono, direccion,nombreCajero, apellidoPaternoCajero, apellidoMaternoCajero);
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        } 
        finally 
        {
            try 
            {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } 
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }
}
