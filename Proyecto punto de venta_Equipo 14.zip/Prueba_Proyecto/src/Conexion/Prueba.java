/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.util.List;

/**
 *
 * @author megan
 */
public class Prueba 
{
    public Conexion_Personal CBP;
    public static void main (String args [])
    {
        Conexion_Personal CBP = new Conexion_Personal ();
        List <String> Lista = CBP.CargosDisponibles();
        for (int x = 0; x < Lista.size(); x++)
        {
            System.out.print(Lista.get(x));
        }
    }
}
