/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author megan
 */
public class Conexion_Producto 
{
    Connection cx;
    Conexion_Base CB;
    
    public Conexion_Producto  ()
    {
        CB = new Conexion_Base ();
    }
    
    public boolean InsertarProducto(String Nombre, int Codigo, String Categoria, String Descripcion, String Proveedor, int Cantidad, double Precio) 
    {
        cx = CB.Conectar();
        boolean resultado = false;
        try 
        {
            // 1. Buscar ID del proveedor
            String[] partesNombre = Proveedor.trim().split("\\s+");
            if (partesNombre.length < 3) 
            {
                return false;
            }
            String nombre = partesNombre[0];
            String apellidoP = partesNombre[1];
            String apellidoM = partesNombre[2];
            String sqlProveedor = "SELECT id FROM proveedor WHERE nombre = ? AND apellido_paterno = ? AND apellido_materno = ?";
            PreparedStatement psProveedor = cx.prepareStatement(sqlProveedor);
            psProveedor.setString(1, nombre);
            psProveedor.setString(2, apellidoP);
            psProveedor.setString(3, apellidoM);
            ResultSet rsProveedor = psProveedor.executeQuery();
            if (!rsProveedor.next()) 
            {
                return false;
            }
            int idProveedor = rsProveedor.getInt("id");
            // 2. Buscar ID de categoría
            String sqlCategoria = "SELECT id FROM categoria WHERE categoria = ?";
            PreparedStatement psCategoria = cx.prepareStatement(sqlCategoria);
            psCategoria.setString(1, Categoria);
            ResultSet rsCategoria = psCategoria.executeQuery();
            if (!rsCategoria.next()) 
            {
                return false;
            }
            int idCategoria = rsCategoria.getInt("id");
            // 3. Verificar si el producto ya existe
            String consulta = "SELECT COUNT(*) FROM producto WHERE nombre = ? AND codigo = ? AND proveedor = ?";
            PreparedStatement psCheck = cx.prepareStatement(consulta);
            psCheck.setString(1, Nombre);
            psCheck.setInt(2, Codigo);
            psCheck.setInt(3, idProveedor);
            ResultSet rs = psCheck.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            if (count > 0) 
            {
                return false; // Ya existe
            }
            // 4. Insertar producto
            String sqlInsert = "INSERT INTO producto (nombre, codigo, categoria, descripcion, proveedor, cantidad, precio) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement psInsert = cx.prepareStatement(sqlInsert);
            psInsert.setString(1, Nombre);
            psInsert.setInt(2, Codigo);
            psInsert.setInt(3, idCategoria);
            psInsert.setString(4, Descripcion);
            psInsert.setInt(5, idProveedor);
            psInsert.setInt(6, Cantidad);
            psInsert.setDouble(7, Precio);
            int filasAfectadas = psInsert.executeUpdate();
            if (filasAfectadas > 0) 
            {
                resultado = true;
            }
        } catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Producto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }

    
    public boolean EliminarProducto (String Nombre, int Codigo)
    {
        cx = CB.Conectar();
        boolean Resultado = false;
        String sql = "DELETE FROM producto WHERE Nombre = ? AND Codigo = ?" ;
        try 
        {
            PreparedStatement preparedStatement = cx.prepareStatement(sql);
            preparedStatement.setString(1, Nombre);
            preparedStatement.setInt(2, Codigo);
            int filasAfectadas = preparedStatement.executeUpdate();
            if (filasAfectadas > 0) 
            {
                Resultado = true;
            } 
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Producto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Resultado;
    }
    
    public boolean ModificarProducto(String nombreOriginal, int codigoOriginal, String nuevoNombre, int CodigoNuevo, String Categoria, String Descripcion, String Proveedor, int Cantidad, double Precio) 
    {
        cx = CB.Conectar();
        boolean resultado = false;
        try 
        {
            // 1. Obtener ID del proveedor a partir del nombre completo
            String[] partesNombre = Proveedor.trim().split("\\s+");
            if (partesNombre.length < 3) 
            {
                return false;
            }
            String nombre = partesNombre[0];
            String apellidoP = partesNombre[1];
            String apellidoM = partesNombre[2];
            String sqlProveedor = "SELECT id FROM proveedor WHERE nombre = ? AND apellido_paterno = ? AND apellido_materno = ?";
            PreparedStatement psProveedor = cx.prepareStatement(sqlProveedor);
            psProveedor.setString(1, nombre);
            psProveedor.setString(2, apellidoP);
            psProveedor.setString(3, apellidoM);
            ResultSet rsProveedor = psProveedor.executeQuery();
            if (!rsProveedor.next()) 
            {
                return false;
            }
            int idProveedor = rsProveedor.getInt("id");
            // 2. Obtener ID de la categoría
            String sqlCategoria = "SELECT id FROM categoria WHERE categoria = ?";
            PreparedStatement psCategoria = cx.prepareStatement(sqlCategoria);
            psCategoria.setString(1, Categoria);
            ResultSet rsCategoria = psCategoria.executeQuery();
            if (!rsCategoria.next()) 
            {
                return false;
            }
            int idCategoria = rsCategoria.getInt("id");
            // 3. Validar duplicado de producto (mismo nombre, distinto código)
            String consulta = "SELECT COUNT(*) FROM producto WHERE nombre = ? AND codigo != ?";
            PreparedStatement psCheck = cx.prepareStatement(consulta);
            psCheck.setString(1, nuevoNombre);
            psCheck.setInt(2, codigoOriginal);
            ResultSet rs = psCheck.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            rs.close();
            psCheck.close();
            if (count > 0) 
            {
                return false; // Ya existe otro producto con el mismo nombre
            }
            // 4. Actualizar producto
            String sqlUpdate = "UPDATE producto SET nombre = ?, codigo = ?, categoria = ?, descripcion = ?, proveedor = ?, cantidad = ?, precio = ? WHERE nombre = ? AND codigo = ?";
            PreparedStatement psUpdate = cx.prepareStatement(sqlUpdate);
            psUpdate.setString(1, nuevoNombre);
            psUpdate.setInt(2, CodigoNuevo);
            psUpdate.setInt(3, idCategoria);
            psUpdate.setString(4, Descripcion);
            psUpdate.setInt(5, idProveedor);
            psUpdate.setInt(6, Cantidad);
            psUpdate.setDouble(7, Precio);
            psUpdate.setString(8, nombreOriginal);
            psUpdate.setInt(9, codigoOriginal);
            int filas = psUpdate.executeUpdate();
            if (filas > 0) 
            {
                resultado = true;
            }
            psUpdate.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Producto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }

    public List<String[]> ListarProductosTipo(String Tipo) 
    {
        cx = CB.Conectar();
        List<String[]> lista = new ArrayList<>();
        try 
        {
            // 1. Obtener el ID de la categoría por nombre
            String sqlCategoria = "SELECT id FROM categoria WHERE categoria = ?";
            PreparedStatement psCategoria = cx.prepareStatement(sqlCategoria);
            psCategoria.setString(1, Tipo);
            ResultSet rsCategoria = psCategoria.executeQuery();
            if (!rsCategoria.next()) 
            {
                return lista; // Retorna lista vacía si no encuentra la categoría
            }
            int idCategoria = rsCategoria.getInt("id");
            // 2. Consultar productos por ID de categoría, excluyendo los de cantidad 0
            String sql = "SELECT nombre, codigo, descripcion, proveedor, cantidad, precio FROM producto WHERE categoria = ? AND cantidad > 0";
            PreparedStatement ps = cx.prepareStatement(sql);
            ps.setInt(1, idCategoria);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) 
            {
                String[] datos = new String[7];
                datos[0] = rs.getString("nombre");
                datos[1] = String.valueOf(rs.getInt("codigo"));
                datos[2] = Tipo;  // Ya tenemos el nombre original de la categoría
                datos[3] = rs.getString("descripcion");
                // 3. Buscar nombre completo del proveedor
                int idProveedor = rs.getInt("proveedor");
                String sqlProveedor = "SELECT nombre, apellido_paterno, apellido_materno FROM proveedor WHERE id = ?";
                PreparedStatement psProv = cx.prepareStatement(sqlProveedor);
                psProv.setInt(1, idProveedor);
                ResultSet rsProv = psProv.executeQuery();
                String nombreProveedor = "Desconocido";
                if (rsProv.next()) 
                {
                    nombreProveedor = rsProv.getString("nombre") + " " + rsProv.getString("apellido_paterno") + " " + rsProv.getString("apellido_materno");
                }
                rsProv.close();
                psProv.close();
                datos[4] = nombreProveedor;
                datos[5] = String.valueOf(rs.getInt("cantidad"));
                datos[6] = String.valueOf(rs.getDouble("precio"));
                lista.add(datos);
            }
            rs.close();
            ps.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Proveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }
    
    public List<String[]> ListarProductos() 
    {
        cx = CB.Conectar();
        List<String[]> lista = new ArrayList<>();
        // Agregamos el filtro "cantidad > 0" en la consulta
        String sql = "SELECT nombre, codigo, categoria, descripcion, proveedor, cantidad, precio FROM producto WHERE cantidad > 0";
        try 
        {
            PreparedStatement ps = cx.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) 
            {
                String[] datos = new String[7];
                // Datos básicos del producto
                datos[0] = rs.getString("nombre");
                datos[1] = String.valueOf(rs.getInt("codigo"));
                datos[3] = rs.getString("descripcion");
                datos[5] = String.valueOf(rs.getInt("cantidad"));
                datos[6] = String.valueOf(rs.getDouble("precio"));
                // 1. Obtener nombre de la categoría
                int idCategoria = rs.getInt("categoria");
                String categoriaNombre = "Desconocida";
                String sqlCategoria = "SELECT categoria FROM categoria WHERE id = ?";
                PreparedStatement psCat = cx.prepareStatement(sqlCategoria);
                psCat.setInt(1, idCategoria);
                ResultSet rsCat = psCat.executeQuery();
                if (rsCat.next()) 
                {
                    categoriaNombre = rsCat.getString("categoria");
                }
                rsCat.close();
                psCat.close();
                datos[2] = categoriaNombre;
                // 2. Obtener nombre completo del proveedor
                int idProveedor = rs.getInt("proveedor");
                String proveedorNombre = "Desconocido";
                String sqlProveedor = "SELECT nombre, apellido_paterno, apellido_materno FROM proveedor WHERE id = ?";
                PreparedStatement psProv = cx.prepareStatement(sqlProveedor);
                psProv.setInt(1, idProveedor);
                ResultSet rsProv = psProv.executeQuery();
                if (rsProv.next()) 
                {
                    proveedorNombre = rsProv.getString("nombre") + " " + rsProv.getString("apellido_paterno") + " " + rsProv.getString("apellido_materno");
                }
                rsProv.close();
                psProv.close();
                datos[4] = proveedorNombre;
                lista.add(datos);
            }
            rs.close();
            ps.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Proveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }

    
    public List <String> CategoriasDisponibles ()
    {
        cx = CB.Conectar();
        List<String> categorias = new ArrayList<>();
        String sql = "SELECT Categoria FROM categoria";
        try 
        {
            PreparedStatement ps = cx.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) 
            {
                categorias.add(rs.getString("Categoria"));
            }
            rs.close();
            ps.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Producto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return categorias;
    }
    
    public boolean VentaProducto (int codigoProducto, int cantidadARestar)
    {
        cx = CB.Conectar(); // Asegúrate de que cx esté conectado
        boolean resultado = false;
        try 
        {
            // Verificar cantidad actual
            String sqlVerificar = "SELECT Cantidad FROM producto WHERE Codigo = ?";
            PreparedStatement psVerificar = cx.prepareStatement(sqlVerificar);
            psVerificar.setInt(1, codigoProducto);
            ResultSet rs = psVerificar.executeQuery();
            if (rs.next()) 
            {
                int cantidadActual = rs.getInt("Cantidad");
                if (cantidadActual >= cantidadARestar) 
                {
                    // Actualizar la cantidad
                    String sqlActualizar = "UPDATE producto SET Cantidad = Cantidad - ? WHERE Codigo = ?";
                    PreparedStatement psActualizar = cx.prepareStatement(sqlActualizar);
                    psActualizar.setInt(1, cantidadARestar);
                    psActualizar.setInt(2, codigoProducto);
                    int filas = psActualizar.executeUpdate();
                    if (filas > 0) {
                        resultado = true;
                    }
                    psActualizar.close();
                }
            }
            psVerificar.close();
            rs.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Producto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
    
    public boolean CancelarCompra(int codigoProducto, int cantidadAReponer) 
    {
        cx = CB.Conectar(); // Asegurarse de que la conexión esté activa
        boolean resultado = false;
        try 
        {
            // Verificar si el producto existe
            String sqlVerificar = "SELECT Cantidad FROM producto WHERE Codigo = ?";
            PreparedStatement psVerificar = cx.prepareStatement(sqlVerificar);
            psVerificar.setInt(1, codigoProducto);
            ResultSet rs = psVerificar.executeQuery();
            if (rs.next()) 
            {
                // Actualizar la cantidad
                String sqlActualizar = "UPDATE producto SET Cantidad = Cantidad + ? WHERE Codigo = ?";
                PreparedStatement psActualizar = cx.prepareStatement(sqlActualizar);
                psActualizar.setInt(1, cantidadAReponer);
                psActualizar.setInt(2, codigoProducto);
                int filas = psActualizar.executeUpdate();
                if (filas > 0) 
                {
                    resultado = true;
                }
                psActualizar.close();
            }
            rs.close();
            psVerificar.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Producto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
}
