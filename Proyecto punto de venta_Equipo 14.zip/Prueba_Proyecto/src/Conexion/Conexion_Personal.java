/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;

/**
 *
 * @author megan
 */
public class Conexion_Personal 
{
    Connection cx;
    Conexion_Base CB;
    
    public Conexion_Personal ()
    {
        CB = new Conexion_Base();
    }
    
    public List<String> CargosDisponibles() 
    {
        cx = CB.Conectar(); // Asegúrate de que CB.Conectar() retorna una conexión válida
        List<String> cargos = new ArrayList<>();
        String sql = "SELECT Cargo FROM cargo"; // Se eliminó el WHERE innecesario
        try (PreparedStatement ps = cx.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) 
        {
            while (rs.next()) 
            {
                cargos.add(rs.getString("Cargo"));
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Personal.class.getName()).log(Level.SEVERE, null, ex);
        }

        return cargos;
    }
    
    public List<String[]> ObtenerPersonalCargo (String cargoNombre) 
    {
        List<String[]> personalList = new ArrayList<>();
        cx = CB.Conectar();
        String sqlIdCargo = "SELECT id FROM cargo WHERE Cargo = ?";
        String sqlPersonal = "SELECT nombre, apellido_paterno, apellido_materno, correo, contraseña FROM personal WHERE cargo = ?";
        try (PreparedStatement psCargo = cx.prepareStatement(sqlIdCargo)) 
        {
            psCargo.setString(1, cargoNombre);
            ResultSet rsCargo = psCargo.executeQuery();
            if (rsCargo.next()) 
            {
                int cargoId = rsCargo.getInt("id");
                try (PreparedStatement psPersonal = cx.prepareStatement(sqlPersonal)) 
                {
                    psPersonal.setInt(1, cargoId);
                    ResultSet rsPersonal = psPersonal.executeQuery();
                    while (rsPersonal.next()) 
                    {
                        String[] datos = new String[6];
                        datos[0] = rsPersonal.getString("nombre");
                        datos[1] = rsPersonal.getString("apellido_paterno");
                        datos[2] = rsPersonal.getString("apellido_materno");
                        datos[3] = rsPersonal.getString("correo");
                        datos[4] = rsPersonal.getString("contraseña");
                        datos[5] = cargoNombre; // Se agrega el nombre del cargo
                        personalList.add(datos);
                    }
                    rsPersonal.close();
                }
            }
            rsCargo.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Personal.class.getName()).log(Level.SEVERE, null, ex);
        }
        return personalList;
    }
    
    public List<String[]> ObtenerPersonal() 
    {
        cx = CB.Conectar();
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT p.nombre, p.apellido_paterno, p.apellido_materno, p.correo, p.contraseña, c.Cargo FROM personal p INNER JOIN cargo c ON p.cargo = c.id";
        try (PreparedStatement ps = cx.prepareStatement(sql); ResultSet rs = ps.executeQuery()) 
        {
            while (rs.next()) 
            {
                String[] fila = new String[6];
                fila[0] = rs.getString("nombre");
                fila[1] = rs.getString("apellido_paterno");
                fila[2] = rs.getString("apellido_materno");
                fila[3] = rs.getString("correo");
                fila[4] = rs.getString("contraseña");
                fila[5] = rs.getString("Cargo"); // Nombre del cargo, no el ID
                lista.add(fila);
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Personal.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }
  
    public boolean InsertarPersonal(String Nombre, String ApellidoP, String ApellidoM, String Contraseña, String Correo, String Cargo) 
    {
        cx = CB.Conectar();
        boolean resultado = false;
        try 
        {
            // 1. Verificar si ya existe una persona con el mismo nombre completo y correo
            String consulta = "SELECT COUNT(*) FROM personal WHERE nombre = ? AND apellido_paterno = ? AND apellido_materno = ? AND correo = ?";
            PreparedStatement psCheck = cx.prepareStatement(consulta);
            psCheck.setString(1, Nombre);
            psCheck.setString(2, ApellidoP);
            psCheck.setString(3, ApellidoM);
            psCheck.setString(4, Correo);
            ResultSet rs = psCheck.executeQuery();
            rs.next();
            int count = rs.getInt(1);
            rs.close();
            psCheck.close();
            if (count > 0) 
            {
                return false; // Ya existe una persona con ese nombre y correo
            }
            // 2. Obtener el ID del cargo
            String sqlCargo = "SELECT id FROM cargo WHERE cargo = ?";
            PreparedStatement psCargo = cx.prepareStatement(sqlCargo);
            psCargo.setString(1, Cargo);
            ResultSet rsCargo = psCargo.executeQuery();
            int cargoId = -1;
            if (rsCargo.next()) 
            {
                cargoId = rsCargo.getInt("id");
            } 
            else 
            {
                rsCargo.close();
                psCargo.close();
                return false; // No se encontró el cargo
            }
            rsCargo.close();
            psCargo.close();
            // 3. Insertar en la tabla personal con el ID del cargo
            String sqlInsert = "INSERT INTO personal (nombre, apellido_paterno, apellido_materno, contraseña, correo, cargo) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = cx.prepareStatement(sqlInsert);
            preparedStatement.setString(1, Nombre);
            preparedStatement.setString(2, ApellidoP);
            preparedStatement.setString(3, ApellidoM);
            preparedStatement.setString(4, Contraseña);
            preparedStatement.setString(5, Correo);
            preparedStatement.setInt(6, cargoId); // ahora es el ID, no el nombre
            int filasAfectadas = preparedStatement.executeUpdate();
            if (filasAfectadas > 0) 
            {
                resultado = true;
            }
            preparedStatement.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Personal.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
   
    public boolean EliminarPersonal(String Correo, String Cargo) 
    {
        cx = CB.Conectar();
        boolean resultado = false;
        try 
        {
            // 1. Obtener el ID del cargo
            String sqlCargo = "SELECT id FROM cargo WHERE cargo = ?";
            PreparedStatement psCargo = cx.prepareStatement(sqlCargo);
            psCargo.setString(1, Cargo);
            ResultSet rsCargo = psCargo.executeQuery();
            int cargoId = -1;
            if (rsCargo.next()) 
            {
                cargoId = rsCargo.getInt("id");
            } 
            else 
            {
                rsCargo.close();
                psCargo.close();
                return false; // No se encontró el cargo
            }
            rsCargo.close();
            psCargo.close();
            // 2. Eliminar de la tabla personal usando el ID del cargo
            String sqlDelete = "DELETE FROM personal WHERE correo = ? AND cargo = ?";
            PreparedStatement psDelete = cx.prepareStatement(sqlDelete);
            psDelete.setString(1, Correo);
            psDelete.setInt(2, cargoId); // se usa el id del cargo, no el nombre
            int filasAfectadas = psDelete.executeUpdate();
            if (filasAfectadas > 0) 
            {
                resultado = true;
            }
            psDelete.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Personal.class.getName()).log(Level.SEVERE, null, ex);
        }

        return resultado;
    }
   
    public boolean ModificarPersonal(String correoOriginal, String cargoOriginal, String nuevoNombre, String nuevoApellidoP, String nuevoApellidoM, String nuevaContraseña, String nuevoCorreo, String nuevoCargo) 
    {
        cx = CB.Conectar();
        boolean resultado = false;
        try 
        {
            // 1. Verificar que no exista otra persona con el mismo nombre completo
            String sqlNombre = "SELECT COUNT(*) FROM personal WHERE Nombre = ? AND apellido_paterno = ? AND apellido_materno = ? AND NOT (Correo = ?)";
            PreparedStatement psNombre = cx.prepareStatement(sqlNombre);
            psNombre.setString(1, nuevoNombre);
            psNombre.setString(2, nuevoApellidoP);
            psNombre.setString(3, nuevoApellidoM);
            psNombre.setString(4, correoOriginal);
            ResultSet rsNombre = psNombre.executeQuery();
            rsNombre.next();
            if (rsNombre.getInt(1) > 0) 
            {
                rsNombre.close();
                psNombre.close();
                return false; // Ya existe alguien con ese nombre completo
            }
            rsNombre.close();
            psNombre.close();
            // 2. Verificar que no exista otra persona con el mismo correo
            String sqlCorreo = "SELECT COUNT(*) FROM personal WHERE Correo = ? AND NOT (Correo = ?)";
            PreparedStatement psCorreo = cx.prepareStatement(sqlCorreo);
            psCorreo.setString(1, nuevoCorreo);
            psCorreo.setString(2, correoOriginal);
            ResultSet rsCorreo = psCorreo.executeQuery();
            rsCorreo.next();
            if (rsCorreo.getInt(1) > 0) 
            {
                rsCorreo.close();
                psCorreo.close();
                return false; // Ya existe alguien con ese correo
            }
            rsCorreo.close();
            psCorreo.close();
            // 3. Obtener el ID del nuevo cargo
            String sqlCargo = "SELECT id FROM cargo WHERE Cargo = ?";
            PreparedStatement psCargo = cx.prepareStatement(sqlCargo);
            psCargo.setString(1, nuevoCargo);
            ResultSet rsCargo = psCargo.executeQuery();
            int cargoId = -1;
            if (rsCargo.next()) 
            {
                cargoId = rsCargo.getInt("id");
            } 
            else 
            {
                rsCargo.close();
                psCargo.close();
                return false; // No se encontró el nuevo cargo
            }
            rsCargo.close();
            psCargo.close();
            // 4. Actualizar el personal con el nuevo cargo (ID)
            String sqlUpdate = "UPDATE personal SET Nombre = ?, Apellido_Paterno = ?, Apellido_Materno = ?, Contraseña = ?, Correo = ?, Cargo = ? WHERE Correo = ?";
            PreparedStatement psUpdate = cx.prepareStatement(sqlUpdate);
            psUpdate.setString(1, nuevoNombre);
            psUpdate.setString(2, nuevoApellidoP);
            psUpdate.setString(3, nuevoApellidoM);
            psUpdate.setString(4, nuevaContraseña);
            psUpdate.setString(5, nuevoCorreo);
            psUpdate.setInt(6, cargoId); // ahora se guarda el id
            psUpdate.setString(7, correoOriginal);
            int filas = psUpdate.executeUpdate();
            if (filas > 0) 
            {
                resultado = true;
            }
            psUpdate.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Personal.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
  
    public boolean VerificarCredenciales(String correo, String contraseña) 
    {
        cx = CB.Conectar();
        boolean accesoPermitido = false;
        String sql = "SELECT * FROM personal WHERE correo = ? AND contraseña = ?";
        try 
        {
            PreparedStatement ps = cx.prepareStatement(sql);
            ps.setString(1, correo);
            ps.setString(2, contraseña);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) 
            {
                accesoPermitido = true; // Se encontró una coincidencia
            }
            rs.close();
            ps.close();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Conexion_Personal.class.getName()).log(Level.SEVERE, null, ex);
        }
        return accesoPermitido;
    }
    
    public String [] BuscarCajero (String Usuario)
    {
        cx = CB.Conectar();
        String [] NombreCajero = new String [3];
        String sql = " SELECT nombre, apellido_paterno, apellido_materno FROM personal WHERE Correo = ?";
        try 
        {
            PreparedStatement ps = cx.prepareStatement(sql);
            ps.setString(1,Usuario);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) 
            {
                NombreCajero [0] = rs.getString("Nombre");
                NombreCajero [1] = rs.getString("apellido_paterno");
                NombreCajero [2] = rs.getString("apellido_materno");
            }
            rs.close();
            ps.close();
        }
        catch (SQLException ex)
        {
            
        }      
        return NombreCajero;
    }
    
    public boolean BuscarCorreo (String usuario, String Nombre, String Cargo) 
    {
        cx = CB.Conectar();
        boolean resultado = false;
        try 
        {
            // 1. Buscar por correo o nombre directamente
            String sql = "SELECT * FROM personal WHERE correo = ? and nombre = ? and cargo = ?";
            String cargoSql = "SELECT id FROM cargo WHERE cargo = ?";
            PreparedStatement ps = cx.prepareStatement(cargoSql);
            ps.setString(1, Cargo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) 
            {
                int cargoId = rs.getInt("id");
                ps = cx.prepareStatement(sql);
                ps.setString(1, usuario);
                ps.setString(2, Nombre);
                ps.setInt(3, cargoId);
                rs = ps.executeQuery();
                if (rs.next())
                {
                    resultado = true;
                }
            }
            rs.close();
            ps.close();
        } 
        catch (SQLException ex) 
        {
            // Aquí podrías loguear o imprimir el error para depuración
            ex.printStackTrace();
        }
        return resultado;
    }
    
    public boolean ModificarContraseña(String correo, String nuevaContraseña, String cargoNombre) 
    {
        boolean resultado = false;
        cx = CB.Conectar(); // Asegúrate de tener una conexión válida
        try 
        {
            // Paso 1: Obtener el ID del cargo desde su nombre
            String sqlCargo = "SELECT id FROM cargo WHERE Cargo = ?";
            PreparedStatement psCargo = cx.prepareStatement(sqlCargo);
            psCargo.setString(1, cargoNombre);
            ResultSet rsCargo = psCargo.executeQuery();
            if (rsCargo.next()) 
            {
                int idCargo = rsCargo.getInt("id");
                System.out.println (idCargo);
                // Paso 2: Actualizar contraseña si coincide correo y cargo
                String sqlUpdate = "UPDATE personal SET contraseña = ? WHERE correo = ? AND cargo = ?";
                PreparedStatement psUpdate = cx.prepareStatement(sqlUpdate);
                psUpdate.setString(1, nuevaContraseña); // Puedes aplicar hash aquí si lo deseas
                psUpdate.setString(2, correo);
                psUpdate.setInt(3, idCargo);
                int filasAfectadas = psUpdate.executeUpdate();
                if (filasAfectadas > 0) 
                {
                    resultado = true;
                }
                psUpdate.close();
            }
            rsCargo.close();
            psCargo.close();
            cx.close(); // Cierra la conexión al final
        } 
        catch (SQLException e) 
        {
            e.printStackTrace(); // O loguear el error si es producción
        }

        return resultado;
    }
    
    public static void main (String args [])
    {
        Conexion_Personal CP = new Conexion_Personal ();
        String [] lista = CP.BuscarCajero("s01389828@gmail.com");
        for (String datos : lista)
        {
            System.out.println (datos);
        }
    }
}
