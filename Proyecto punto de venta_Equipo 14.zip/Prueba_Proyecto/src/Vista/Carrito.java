/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;
import Conexion.Conexion_Clientes;
import Conexion.Conexion_Personal;
import Conexion.Conexion_Producto;
import Conexion.Conexion_Ventas;
import Conexion.Correo_Creado;
import Conexion.Validacion;
import jakarta.mail.MessagingException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author santi
 */
public class Carrito extends javax.swing.JFrame 
{
    
    List <String [] > Ticket = new ArrayList<>();
    private final Conexion_Producto CBPr;
    private String categoriaActual = "Todas";
    private Correo_Creado CC;
    private Conexion_Clientes CBL;
    private String UsuarioCajero;
    private Conexion_Personal CBP;
    private Validacion Lector;
    private Conexion_Ventas CV;
  
    public Carrito(String UsuarioCajero) 
    {
        initComponents();      
        CBPr = new Conexion_Producto ();
        CC = new Correo_Creado ();
        CBL = new Conexion_Clientes ();
        LlenarClientes ();
        CBP = new Conexion_Personal();
        this.UsuarioCajero = UsuarioCajero;
        Lector = new Validacion ();
        Lector.soloNumeros(txtCantidadElegida);
        CV = new Conexion_Ventas ();
    }
    
    public void LlenarTablaProductos (List <String[]> lista)
    {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Nombre");
        modelo.addColumn("Codigo");
        modelo.addColumn("Categoria");
        modelo.addColumn("Descripcion");
        modelo.addColumn("Proveedor");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Precio");
        for (String[] productos : lista) 
        {
            modelo.addRow(productos);
        }
        TableProductos.setModel(modelo);
    }
    
    public void LlenarTablaVenta(List<String[]> lista) 
    {
        // Mapa para agrupar productos por su código
        Map<String, String[]> productosAgrupados = new LinkedHashMap<>();
        for (String[] producto : lista) 
        {
            String codigo = producto[1]; // Asumiendo que el código está en la posición 1
            int cantidad = Integer.parseInt(producto[2]);
            double precio = Double.parseDouble(producto[3]);
            double total = Double.parseDouble(producto[4]);
            if (productosAgrupados.containsKey(codigo)) 
            {
                String[] existente = productosAgrupados.get(codigo);
                int nuevaCantidad = Integer.parseInt(existente[2]) + cantidad;
                double nuevoTotal = nuevaCantidad * precio;
                existente[2] = String.valueOf(nuevaCantidad);
                existente[4] = String.format("%.2f", nuevoTotal);
                // El precio se asume constante, no se actualiza
            } 
            else 
            {
                productosAgrupados.put(codigo, Arrays.copyOf(producto, producto.length));
            }
        }
        // Crear el modelo de tabla
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Producto");
        modelo.addColumn("Codigo");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Precio");
        modelo.addColumn("Total");
        for (String[] producto : productosAgrupados.values()) 
        {
            modelo.addRow(producto);
        }
        TableVenta.setModel(modelo);
    }
    
    public void CancelarVenta(List<String[]> ticket) 
    {
        for (String[] producto : ticket) 
        {
            try 
            {
                int codigo = Integer.parseInt(producto[1]);  // Índice 1 = código del producto
                int cantidad = Integer.parseInt(producto[2]); // Índice 2 = cantidad vendida
                // Cancelar la venta (revertir el stock en la base de datos)
                CBPr.CancelarCompra (codigo, cantidad);
            } 
            catch (NumberFormatException e) 
            {
                System.err.println("Error al cancelar producto (formato inválido): " + Arrays.toString(producto));
            }
        }
        // Vaciar la lista de productos
        ticket.clear();
        System.out.println("Venta cancelada. Ticket vaciado y stock restablecido.");
    }

    public void LlenarClientes ()
    {
        cbxCorreoCliente.removeAllItems();
        List <String> lista = CBL.ListarClientesCorreo();
        Set<String> sinDuplicados = new LinkedHashSet<>(lista);
        for (String nombre : sinDuplicados) 
        {
            cbxCorreoCliente.addItem(nombre);
        }
        cbxCorreoCliente.setSelectedItem(null);
    }
    
    public String calcularTotalTicket(List<String[]> ticket) 
    {
        double total = 0.0;
        for (String[] producto : ticket) 
        {
            try 
            {
                total += Double.parseDouble(producto[4]); // producto[4] = total por producto
            } 
            catch (NumberFormatException e) 
            {
                System.err.println("Error al convertir a número: " + producto[4]);
            }
        }
        return String.format("%.2f", total); // Formato con 2 decimales
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnTiendita = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        TablePanel = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableProductos = new javax.swing.JTable();
        btnConfirmarProducto = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txtCantidadElegida = new javax.swing.JTextField();
        txtResultado = new javax.swing.JLabel();
        btnCategoria = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TableVenta = new javax.swing.JTable();
        btnCancelarCompra = new javax.swing.JButton();
        btnPagar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnEliminarProducto = new javax.swing.JButton();
        cbxCorreoCliente = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        txtTotalPagar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(44, 58, 84));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnTiendita.setText("Tiendita");
        btnTiendita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTienditaActionPerformed(evt);
            }
        });
        jPanel1.add(btnTiendita, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, -1));

        btnCerrar.setText("Cerrar Sesion");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });
        jPanel1.add(btnCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));

        btnRegresar.setText("Regresar");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, -1, -1));

        jPanel4.setBackground(new java.awt.Color(153, 0, 51));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Verdana", 1, 60)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 249, 240));
        jLabel2.setText("Mercad - ITO");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(269, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 507, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(254, 254, 254))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(67, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(39, 39, 39))
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, -40, 1030, 180));

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TableProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Codigo", "Categoria", "Descripcion", "Proveedor", "Cantidad", "Precio"
            }
        ));
        jScrollPane1.setViewportView(TableProductos);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 680, 350));

        btnConfirmarProducto.setText("Agregar producto");
        btnConfirmarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarProductoActionPerformed(evt);
            }
        });
        jPanel3.add(btnConfirmarProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 160, -1, -1));

        jLabel3.setText("¿Cuantos deseas agregar?");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 200, -1, -1));
        jPanel3.add(txtCantidadElegida, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 240, 71, -1));

        txtResultado.setFont(new java.awt.Font("Segoe UI Semibold", 0, 8)); // NOI18N
        txtResultado.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(txtResultado, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 280, 140, 46));

        btnCategoria.setText("Seleccionar Categoria");
        btnCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCategoriaActionPerformed(evt);
            }
        });
        jPanel3.add(btnCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 80, -1, -1));

        TablePanel.addTab("Elegir", jPanel3);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TableVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Producto", "Codigo", "Cantidad", "Precio", "Total"
            }
        ));
        jScrollPane2.setViewportView(TableVenta);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 17, 652, 340));

        btnCancelarCompra.setText("Cancelar compra");
        btnCancelarCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarCompraActionPerformed(evt);
            }
        });
        jPanel2.add(btnCancelarCompra, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 130, -1, -1));

        btnPagar.setText("Pagar");
        btnPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPagarActionPerformed(evt);
            }
        });
        jPanel2.add(btnPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 230, -1, -1));

        jLabel1.setText("Correo de Cliente");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 40, -1, -1));

        btnEliminarProducto.setText("Eliminar producto");
        btnEliminarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarProductoActionPerformed(evt);
            }
        });
        jPanel2.add(btnEliminarProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 180, -1, -1));

        jPanel2.add(cbxCorreoCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 70, 160, -1));

        jLabel4.setText("Total a pagar:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 290, -1, -1));

        txtTotalPagar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtTotalPagar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.add(txtTotalPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 320, 80, 20));

        TablePanel.addTab("Venta", jPanel2);

        jPanel1.add(TablePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(141, 99, 880, 410));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnTienditaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTienditaActionPerformed
        // TODO add your handling code here:
        TablePanel.setSelectedIndex(1);
        LlenarTablaVenta(Ticket);
        txtTotalPagar.setText(calcularTotalTicket(Ticket));
    }//GEN-LAST:event_btnTienditaActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        // TODO add your handling code here:
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas salir?",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            Login lo = new Login ();
            lo.setVisible(true);
            this.dispose(); // Cierra la ventana
        }
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void btnConfirmarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarProductoActionPerformed
        int filaSeleccionada = TableProductos.getSelectedRow();
        if (filaSeleccionada == -1) 
        {
            txtResultado.setText("Selecciona un producto.");
        }
        String cantidadStr = txtCantidadElegida.getText().trim(); 
        if (cantidadStr.isEmpty()) 
        {
            txtResultado.setText("Ingresa una cantidad.");
        }
        try 
        {
            int cantidad = Integer.parseInt(cantidadStr);
            if (cantidad <= 0) 
            {
                txtResultado.setText("La cantidad debe ser mayor a cero.");
            }
            int stockDisponible = Integer.parseInt(TableProductos.getValueAt(filaSeleccionada, 5).toString());
            if (cantidad > stockDisponible) 
            {
                txtResultado.setText("No hay suficiente stock disponible.");
            }
            String nombre = TableProductos.getValueAt(filaSeleccionada, 0).toString();
            int codigo = Integer.parseInt(TableProductos.getValueAt(filaSeleccionada, 1).toString());
            double precio = Double.parseDouble(TableProductos.getValueAt(filaSeleccionada, 6).toString()); // Suponiendo columna 4 = precio
            // Calcular total
            double total = cantidad * precio;
            // Formar string y agregar a la lista
            String [] productoVen = new String [5];
            productoVen [0] = nombre;
            productoVen [1] = Integer.toString(codigo);
            productoVen [2] = Integer.toString(cantidad);
            productoVen [3] = Double.toString(precio);
            productoVen [4] = Double.toString(total);
            Ticket.add(productoVen);
            CBPr.VentaProducto(codigo, cantidad);
            List<String[]> datos;
            if (categoriaActual.equals("Todas")) 
            {
                datos = CBPr.ListarProductos();
            } 
            else 
            {
                datos = CBPr.ListarProductosTipo(categoriaActual);
            }
            LlenarTablaProductos(datos);
            txtCantidadElegida.setText("");
        } 
        catch (NumberFormatException e) 
        {
            JOptionPane.showMessageDialog(this, "Ingresa un número válido.");
        }
    }//GEN-LAST:event_btnConfirmarProductoActionPerformed

    private void btnCancelarCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarCompraActionPerformed
        // TODO add your handling code here:
        CancelarVenta (Ticket);
    }//GEN-LAST:event_btnCancelarCompraActionPerformed

    private void btnPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPagarActionPerformed
        String [] cajero = CBP.BuscarCajero(UsuarioCajero);
        String [] cliente = CBL.DatosCliente( (String) cbxCorreoCliente.getSelectedItem());
        String NombreCliente = cliente[0] + " " + cliente[1] + " " + cliente [2];
        CC.generarRutaPDF("Venta", null);
        CC.CrearPDFVenta(Ticket, NombreCliente, cliente [3], cliente [4], cajero [0], cajero [1], cajero [2]);
        try 
        {
            if (!"".equals(cbxCorreoCliente.getSelectedItem()))
            {
                CC.EnviarCorreo((String) cbxCorreoCliente.getSelectedItem(),"Ticket de Venta");
                if (CV.registrarVenta((String) cbxCorreoCliente.getSelectedItem(), UsuarioCajero,Ticket))
                {
                    Ticket.clear();
                    LlenarTablaVenta (Ticket);
                    txtTotalPagar.setText("");
                    JOptionPane.showMessageDialog(this, "Pago realizado exitosamente.");
                }
                else
                {
                    JOptionPane.showMessageDialog(this, "Error al registrar la venta");
                }
            }
            else
            {
                JOptionPane.showMessageDialog(this, "Escoge el correo de un usuario.");
            }
        } 
        catch (MessagingException ex) 
        {
            Logger.getLogger(Carrito.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnPagarActionPerformed

    private void btnEliminarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarProductoActionPerformed
        // TODO add your handling code here:
        int fila = TableVenta.getSelectedRow();
        int codigo = Integer.parseInt(TableVenta.getValueAt(fila, 1).toString());
        int cantidad = Integer.parseInt(TableVenta.getValueAt(fila, 2).toString());
        if (CBPr.CancelarCompra(codigo, cantidad)) 
        {
            
            JOptionPane.showMessageDialog(this, "Producto Eliminado.");
            for (int i = 0; i < Ticket.size(); i++) 
            {
                String[] producto = Ticket.get(i);
                if (Integer.parseInt(producto[1]) == codigo) 
                {
                    Ticket.remove(i);
                }
            }
            // Volver a llenar la tabla con lo que queda en Ticket
            LlenarTablaVenta (Ticket);
        } 
        else 
        {
            JOptionPane.showMessageDialog(this, "Selecciona un producto para eliminar.");
        }
    }//GEN-LAST:event_btnEliminarProductoActionPerformed

    private void btnCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCategoriaActionPerformed
        // TODO add your handling code here:
        JPanel panelCategoria = new JPanel();
        panelCategoria.setLayout(new BoxLayout(panelCategoria, BoxLayout.Y_AXIS));
        panelCategoria.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JLabel lblTitulo = new JLabel("Escoge la categoria que quieras ver:");
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        JComboBox<String> comboCategoria= new JComboBox<>();
        comboCategoria.setAlignmentX(Component.LEFT_ALIGNMENT);
        comboCategoria.addItem("Todas");
        // Cargar cargos desde la base de datos
        List<String> cargos = CBPr.CategoriasDisponibles();
        for (String cargo : cargos) 
        {
            comboCategoria.addItem(cargo);
        }
        JLabel lblAdvertencia = new JLabel("");
        lblAdvertencia.setForeground(Color.RED);
        lblAdvertencia.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Botón aceptar
        JButton btnAceptar = new JButton("Aceptar");
        // Lo centramos horizontalmente
        btnAceptar.setAlignmentX(Component.CENTER_ALIGNMENT);
        // Crear el diálogo personalizado
        JDialog dialog = new JDialog((Frame) null, "Filtrar Categorias", true);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setLayout(new BorderLayout());
        // Acción del botón aceptar
        btnAceptar.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                String seleccionado = (String) comboCategoria.getSelectedItem();
                categoriaActual = seleccionado;
                if (seleccionado == null || seleccionado.isEmpty()) 
                {
                    lblAdvertencia.setText("No has escogido ningúna categoria.");
                    return;
                }
                lblAdvertencia.setText(""); // Limpiar advertencia
                // Actualiza tu tabla existente
                List<String[]> datos;
                if (seleccionado.equals("Todas")) 
                {
                    datos = CBPr.ListarProductos();
                } 
                else 
                {
                    datos = CBPr.ListarProductosTipo(categoriaActual);
                }
                LlenarTablaProductos(datos);
                dialog.dispose(); // Cierra el panel después de aceptar
            }
        });
        // Agregar componentes al panel
        panelCategoria.add(lblTitulo);
        panelCategoria.add(Box.createVerticalStrut(10));
        panelCategoria.add(comboCategoria);
        panelCategoria.add(Box.createVerticalStrut(10));
        panelCategoria.add(btnAceptar);
        panelCategoria.add(Box.createVerticalStrut(10));
        panelCategoria.add(lblAdvertencia);
        // Agregar panel al diálogo
        dialog.add(panelCategoria, BorderLayout.CENTER);
        dialog.pack();
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
    }//GEN-LAST:event_btnCategoriaActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        // TODO add your handling code here:
        LlenarTablaProductos (CBPr.ListarProductosTipo(categoriaActual));
        TablePanel.setSelectedIndex(0);
    }//GEN-LAST:event_btnRegresarActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane TablePanel;
    private javax.swing.JTable TableProductos;
    private javax.swing.JTable TableVenta;
    private javax.swing.JButton btnCancelarCompra;
    private javax.swing.JButton btnCategoria;
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnConfirmarProducto;
    private javax.swing.JButton btnEliminarProducto;
    private javax.swing.JButton btnPagar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnTiendita;
    private javax.swing.JComboBox<String> cbxCorreoCliente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtCantidadElegida;
    private javax.swing.JLabel txtResultado;
    private javax.swing.JLabel txtTotalPagar;
    // End of variables declaration//GEN-END:variables
}
