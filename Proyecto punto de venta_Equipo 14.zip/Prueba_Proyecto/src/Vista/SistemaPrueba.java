/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Conexion.Conexion_Clientes;
import Conexion.Conexion_Personal;
import Conexion.Conexion_Producto;
import Conexion.Conexion_Proveedor;
import Conexion.Conexion_Ventas;
import Conexion.Correo_Creado;
import Conexion.Validacion;
import jakarta.mail.MessagingException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
//import Conexion.Correo_Creado;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author USUARIO
 */
public final class SistemaPrueba extends javax.swing.JFrame 
{
    DefaultTableModel modelo = new DefaultTableModel();
    private final Conexion_Proveedor CBP;
    private final Conexion_Producto CBPr;
    private final Conexion_Clientes CBC;
    private final Conexion_Ventas CBV;
    private final Conexion_Personal CBPe;
    private Correo_Creado CC;
    private Validacion Lector;
    private String codigoEsperado;
    private String Categoria_Seleccionada = "Todas";
    private String Cargo_Seleccionada = "Todas";

    public SistemaPrueba() 
    {
        initComponents();
        CBP = new Conexion_Proveedor ();
        CBPr = new Conexion_Producto ();
        CBC = new Conexion_Clientes ();
        CBV = new Conexion_Ventas ();
        CBPe = new Conexion_Personal ();
        this.setLocationRelativeTo(null);
        LlenarProveedor ();
        LlenarPersonal ();
        LlenarCategoria ();
        jTabbedPane1.setSelectedIndex(5);
        Lector = new Validacion ();
        Validaciones ();
        CC = new Correo_Creado ();
        codigoEsperado = Lector.GenerarCodigos();
    }

    public void LimpiarTable() 
    {
        for (int i = 0; i < modelo.getRowCount(); i++) 
        {
            modelo.removeRow(i);
            i = i - 1;
        }
    }
    
    private void LimpiarCliente() 
    {
        txtNombreCliente.setText("");
        txtTelefonoCliente.setText("");
        txtDirecionCliente.setText("");
        txtApellidoP.setText("");
        txtApellidoM.setText("");
        txtCorreoCli.setText("");
    }

    private void LimpiarProveedor() 
    {
        txtNombreproveedor.setText("");
        txtTelefonoProveedor.setText("");
        txtDireccionProveedor.setText("");
        txtApellidoPaterno.setText("");
        txtApellidoMaterno.setText("");
    }

    private void LimpiarProductos() 
    {
        txtNombreProducto.setText("");
        txtCodigoPro.setText("");
        cbxListaPro.setSelectedItem(null);
        txtDesPro.setText("");
        txtCantPro.setText("");
        txtPrecioPro.setText("");
        cbxCategoria.setSelectedItem(null);
    }
    
    public void LimpiarPersonal ()
    {
        txtNombrePersonal.setText("");
        txtApellidoPPersonal.setText("");
        txtApellidoMPersonal.setText("");
        passContraPersonal.setText("");
        txtCorreoPersonal.setText("");
        cbxCargoPersonal.setSelectedItem(null);
    }
    
    public void LlenarTablaProveedores() 
    {
        modelo = new DefaultTableModel();
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido Paterno");
        modelo.addColumn("Apellido Materno");
        modelo.addColumn("Teléfono");
        modelo.addColumn("Dirección");
        List<String[]> lista = CBP.ListarProveedoresCompleto();
        for (String[] proveedor : lista) 
        {
            modelo.addRow(proveedor);
        }
        TableProveedor.setModel(modelo);
    }
    
    public void LlenarTablaProductos (List <String[]> lista)
    {
        modelo = new DefaultTableModel();
        modelo.addColumn("Nombre");
        modelo.addColumn("Codigo");
        modelo.addColumn("Categoria");
        modelo.addColumn("Descripcion");
        modelo.addColumn("Proveedor");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Precio");
        for (String[] productos : lista) 
        {
            modelo.addRow(productos);
        }

        TableProducto.setModel(modelo);
    }
    
    public void LlenarTablaClientes ()
    {
        modelo = new DefaultTableModel();
        modelo.addColumn("Nombre");
        modelo.addColumn("ApellidoP");
        modelo.addColumn("ApellidoM");
        modelo.addColumn("Telefono");
        modelo.addColumn("Correo");
        modelo.addColumn("Direccion");
        List <String[]> lista = CBC.ListarClientes();
        for (String[] cliente : lista) 
        {
            modelo.addRow(cliente);
        }
        TableCliente.setModel(modelo);
    }
    
    public void LlenarTablaPersonal (List <String[]> lista)
    {
        modelo = new DefaultTableModel();
        modelo.addColumn("Nombre");
        modelo.addColumn("ApellidoP");
        modelo.addColumn("ApellidoM");
        modelo.addColumn("Correo");
        modelo.addColumn("Contraseña");
        modelo.addColumn("Cargo");
        for (String[] admin : lista) 
        {
            modelo.addRow(admin);
        }
        TablePersonal.setModel(modelo);
    }
    
    public void LlenarTablaVentas ()
    {
        modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Cliente");
        modelo.addColumn("Vendedor");
        modelo.addColumn("Total");
        modelo.addColumn("Fecha Venta");
        List <String[]> lista = CBV.obtenerReporteVentas();
        for (String[] venta : lista) 
        {
            modelo.addRow(venta);
        }
        TableVentas.setModel(modelo);
    }
    
    public void EliminarProveedor ()
    {
        int filaSeleccionada = TableProveedor.getSelectedRow();
        if (filaSeleccionada != -1) 
        {
            String nombre = (String) TableProveedor.getValueAt(filaSeleccionada, 0); // Columna 0 = Nombre
            String apeP = (String) TableProveedor.getValueAt(filaSeleccionada, 1); 
            String apeM = (String) TableProveedor.getValueAt(filaSeleccionada, 2); 
            int confirmacion = JOptionPane.showConfirmDialog(null, 
                "¿Estás seguro de eliminar al proveedor: " + nombre + "?", 
                "Confirmar eliminación", 
                JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) 
            {
                boolean eliminado = CBP.EliminarProveedor(nombre, apeP, apeM);
                if (eliminado) 
                {
                    JOptionPane.showMessageDialog(null, "Proveedor eliminado correctamente.");
                    LlenarTablaProveedores(); // Recarga la tabla
                    LimpiarProveedor();
                } 
                else 
                {
                    JOptionPane.showMessageDialog(null, "No se pudo eliminar al proveedor.");
                }
            }
        } 
        else 
        {
            JOptionPane.showMessageDialog(null, "Selecciona un proveedor de la tabla.");
        }
    }
    
    public void EliminarProductos ()
    {
        int filaSeleccionada = TableProducto.getSelectedRow();
        if (filaSeleccionada != -1) 
        {
            String nombre = (String) TableProducto.getValueAt(filaSeleccionada, 0);
            String codigoStr = (String) TableProducto.getValueAt(filaSeleccionada, 1);
            int codigo = Integer.parseInt(codigoStr);
            int confirmacion = JOptionPane.showConfirmDialog(null, 
                "¿Estás seguro de eliminar al prodcuto: " + nombre + " (Código: " + codigo + ")?", 
                "Confirmar eliminación", 
                JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) 
            {
                boolean eliminado = CBPr.EliminarProducto(nombre, codigo);
                if (eliminado) 
                {
                    JOptionPane.showMessageDialog(null, "Producto eliminado correctamente.");
                    LimpiarProductos();
                    Categoria_Seleccionada = (String) TableProducto.getValueAt(filaSeleccionada, 2);
                    LlenarTablaProductos (CBPr.ListarProductosTipo(Categoria_Seleccionada));
                } 
                else 
                {
                    JOptionPane.showMessageDialog(null, "No se pudo eliminar el producto.");
                }
            }
        } 
        else 
        {
            JOptionPane.showMessageDialog(null, "Selecciona un producto de la tabla.");
        }
    }

    public void EliminarCliente ()
    {
        int filaSeleccionada = TableCliente.getSelectedRow();
        if (filaSeleccionada != -1) 
        {
            String nombre = (String) TableCliente.getValueAt(filaSeleccionada, 0);
            String apeP = (String) TableCliente.getValueAt(filaSeleccionada, 1);
            String apeM = (String) TableCliente.getValueAt(filaSeleccionada, 2);
            int confirmacion = JOptionPane.showConfirmDialog(null,
                "¿Estás seguro de eliminar al cliente: " + nombre + " " + apeP + " " + apeM + " ?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) 
            {
                boolean eliminado = CBC.EliminarCliente(nombre, apeP, apeM);
                if (eliminado) 
                {
                    JOptionPane.showMessageDialog(null, "Cliente eliminado correctamente.");
                    LimpiarCliente(); // Recarga la tabla
                    LlenarTablaClientes();
                } 
                else 
                {
                    JOptionPane.showMessageDialog(null, "No se pudo eliminar el cliente.");
                }
            }
        } 
        else 
        {
            JOptionPane.showMessageDialog(null, "Selecciona un cliente de la tabla.");
        }
    }
    
    public void EliminarPersonal ()
    {
        int filaSeleccionada = TablePersonal.getSelectedRow();
        if (filaSeleccionada != -1) 
        {
            String correo = (String) TablePersonal.getValueAt(filaSeleccionada, 3);
            String cargo = (String) TablePersonal.getValueAt(filaSeleccionada, 5);
            int confirmacion = JOptionPane.showConfirmDialog(null, 
                "¿Estás seguro de eliminar al Personal con el: " + cargo + " (y con el correo : " + correo + ")?", 
                "Confirmar eliminación", 
                JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) 
            {
                boolean eliminado = CBPe.EliminarPersonal(correo, cargo);
                if (eliminado) 
                {
                    JOptionPane.showMessageDialog(null, "Personal eliminado correctamente.");
                    LimpiarPersonal();
                    Cargo_Seleccionada = (String) TablePersonal.getValueAt(filaSeleccionada, 5);
                    LlenarTablaPersonal (CBPe.ObtenerPersonalCargo(Cargo_Seleccionada));
                    
                } 
                else 
                {
                    JOptionPane.showMessageDialog(null, "No se pudo eliminar al Personal.");
                }
            }
        } 
        else 
        {
            JOptionPane.showMessageDialog(null, "Selecciona un Personal de la tabla.");
        }
    }
    
    public void EliminarVentas ()
    {
        int filaSeleccionada = TableVentas.getSelectedRow();
        if (filaSeleccionada != -1) 
        {
            String idString = (String) TableVentas.getValueAt(filaSeleccionada, 0);
            String fecha = (String) TableVentas.getValueAt(filaSeleccionada, 4);
            int id = Integer.parseInt(idString);
            int confirmacion = JOptionPane.showConfirmDialog(null, 
                "¿Estás seguro de eliminar a la venta : " + idString + " (en la fecha : " + fecha + ")?", 
                "Confirmar eliminación", 
                JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) 
            {
                boolean eliminado = CBV.EliminarVenta(id);
                if (eliminado) 
                {
                    JOptionPane.showMessageDialog(null, "Venta eliminada correctamente.");
                    LlenarTablaVentas(); // Recarga la tabla
                    LimpiarProductos();
                } 
                else 
                {
                    JOptionPane.showMessageDialog(null, "No se pudo eliminar la venta.");
                }
            }
        } 
        else 
        {
            JOptionPane.showMessageDialog(null, "Selecciona una venta de la tabla.");
        }
    }
    
    private void LlenarProveedor ()
    {
        cbxListaPro.removeAllItems();
        List <String> lista = CBP.ListarNombresProveedores();
        Set<String> sinDuplicados = new LinkedHashSet<>(lista);
        for (String nombre : sinDuplicados) 
        {
            cbxListaPro.addItem(nombre);
        }
        cbxListaPro.setSelectedItem(null);
    }
    
    public void LlenarPersonal ()
    {
        cbxCargoPersonal.removeAllItems();
        List <String> lista = CBPe.CargosDisponibles();
        Set<String> sinDuplicados = new LinkedHashSet<>(lista);
        for (String nombre : sinDuplicados) 
        {
            cbxCargoPersonal.addItem(nombre);
        }
        cbxCargoPersonal.setSelectedItem(null);
    }
    
    public void LlenarCategoria ()
    {
        cbxCategoria.removeAllItems();
        List <String> lista = CBPr.CategoriasDisponibles();
        Set<String> sinDuplicados = new LinkedHashSet<>(lista);
        for (String nombre : sinDuplicados) 
        {
            cbxCategoria.addItem(nombre);
        }
        cbxCategoria.setSelectedItem(null);
    }

    public void Validaciones ()
    {
        Lector.soloLetras(txtNombreCliente);
        Lector.soloLetras(txtApellidoP);
        Lector.soloLetras(txtApellidoM);
        Lector.soloNumeros(txtTelefonoCliente);
        Lector.soloLetras(txtNombreproveedor);
        Lector.soloLetras (txtApellidoPaterno);
        Lector.soloLetras (txtApellidoMaterno);
        Lector.soloNumeros (txtTelefonoProveedor);
        Lector.soloLetras (txtNombreProducto);
        Lector.soloNumeros (txtCodigoPro);
        Lector.soloLetras (txtDesPro);
        Lector.soloNumeros (txtCantPro);
        Lector.Precio (txtPrecioPro);
        Lector.soloLetras (txtNombrePersonal);
        Lector.soloLetras (txtApellidoPPersonal);
        Lector.soloLetras (txtApellidoMPersonal);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        tipo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TableCliente = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        txtNombreCliente = new javax.swing.JTextField();
        txtTelefonoCliente = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtDirecionCliente = new javax.swing.JTextField();
        btnGuardarCliente = new javax.swing.JButton();
        btnEditarCliente = new javax.swing.JButton();
        btnEliminarCliente = new javax.swing.JButton();
        btnNuevoCliente = new javax.swing.JButton();
        btnMostrar2 = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        txtApellidoP = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        txtApellidoM = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        txtCorreoCli = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        TableProveedor = new javax.swing.JTable();
        jPanel10 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        txtNombreproveedor = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        txtTelefonoProveedor = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        txtDireccionProveedor = new javax.swing.JTextField();
        btnguardarProveedor = new javax.swing.JButton();
        btnEditarProveedor = new javax.swing.JButton();
        btnNuevoProveedor = new javax.swing.JButton();
        btnEliminarProveedor = new javax.swing.JButton();
        btnMostrar1 = new javax.swing.JButton();
        jLabel39 = new javax.swing.JLabel();
        txtApellidoPaterno = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        txtApellidoMaterno = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        TableProducto = new javax.swing.JTable();
        jPanel11 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        txtCodigoPro = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        txtCantPro = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        txtPrecioPro = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        btnGuardarpro = new javax.swing.JButton();
        btnEditarpro = new javax.swing.JButton();
        btnEliminarPro = new javax.swing.JButton();
        btnNuevoPro = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        cbxListaPro = new javax.swing.JComboBox<>();
        jLabel23 = new javax.swing.JLabel();
        txtDesPro = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        txtNombreProducto = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        cbxCategoria = new javax.swing.JComboBox<>();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        TableVentas = new javax.swing.JTable();
        btnPdfVentas = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        btnMostrar3 = new javax.swing.JButton();
        btnEliminarVenta = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        btnMostrar4 = new javax.swing.JButton();
        btnGuardarPersonal = new javax.swing.JButton();
        btnEliminarPersonal = new javax.swing.JButton();
        btnNuevoPersonal = new javax.swing.JButton();
        btnEditarPersonal = new javax.swing.JButton();
        jLabel47 = new javax.swing.JLabel();
        txtNombrePersonal = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        txtApellidoPPersonal = new javax.swing.JTextField();
        txtApellidoMPersonal = new javax.swing.JTextField();
        jLabel49 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        passContraPersonal = new javax.swing.JPasswordField();
        jLabel52 = new javax.swing.JLabel();
        txtCorreoPersonal = new javax.swing.JTextField();
        jLabel59 = new javax.swing.JLabel();
        cbxCargoPersonal = new javax.swing.JComboBox<>();
        iconContraseña = new javax.swing.JLabel();
        TableAdmin = new javax.swing.JScrollPane();
        TablePersonal = new javax.swing.JTable();
        jPanel13 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        tipo1 = new javax.swing.JLabel();
        LabelVendedor = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        btnClientes = new javax.swing.JButton();
        btnProveedor = new javax.swing.JButton();
        btnProductos = new javax.swing.JButton();
        btnVentas = new javax.swing.JButton();
        btnPersonal = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(102, 0, 0));

        tipo.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Verdana", 1, 60)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 249, 240));
        jLabel1.setText("Mercad - ITO");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addComponent(tipo)
                .addContainerGap(723, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(178, 178, 178))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel1)
                .addGap(267, 267, 267)
                .addComponent(tipo)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 0, 860, 130));

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TableCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "ApellidoPaterno", "ApellidoMaterno", "Telefono", "Correo", "Direccion"
            }
        ));
        TableCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableClienteMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TableCliente);
        if (TableCliente.getColumnModel().getColumnCount() > 0) {
            TableCliente.getColumnModel().getColumn(0).setPreferredWidth(10);
            TableCliente.getColumnModel().getColumn(1).setPreferredWidth(50);
            TableCliente.getColumnModel().getColumn(2).setPreferredWidth(100);
            TableCliente.getColumnModel().getColumn(3).setPreferredWidth(50);
            TableCliente.getColumnModel().getColumn(4).setPreferredWidth(80);
        }

        jPanel3.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(265, 20, 590, 400));

        jPanel9.setBackground(new java.awt.Color(204, 204, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder("Registro Cliente"));
        jPanel9.setLayout(null);

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("Nombre:");
        jPanel9.add(jLabel13);
        jLabel13.setBounds(5, 28, 60, 15);
        jPanel9.add(txtNombreCliente);
        txtNombreCliente.setBounds(114, 24, 129, 22);
        jPanel9.add(txtTelefonoCliente);
        txtTelefonoCliente.setBounds(114, 138, 129, 22);

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("Télefono:");
        jPanel9.add(jLabel14);
        jLabel14.setBounds(5, 142, 57, 15);

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setText("Dirección:");
        jPanel9.add(jLabel15);
        jLabel15.setBounds(5, 218, 62, 15);
        jPanel9.add(txtDirecionCliente);
        txtDirecionCliente.setBounds(114, 218, 129, 22);

        btnGuardarCliente.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnGuardarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/GuardarTodo.png"))); // NOI18N
        btnGuardarCliente.setText("  Guardar");
        btnGuardarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnGuardarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarClienteActionPerformed(evt);
            }
        });
        jPanel9.add(btnGuardarCliente);
        btnGuardarCliente.setBounds(21, 316, 100, 32);

        btnEditarCliente.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnEditarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actualizar (2).png"))); // NOI18N
        btnEditarCliente.setText("Modificar");
        btnEditarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnEditarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarClienteActionPerformed(evt);
            }
        });
        jPanel9.add(btnEditarCliente);
        btnEditarCliente.setBounds(19, 354, 102, 31);

        btnEliminarCliente.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnEliminarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/eliminar.png"))); // NOI18N
        btnEliminarCliente.setText("   Eliminar");
        btnEliminarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnEliminarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarClienteActionPerformed(evt);
            }
        });
        jPanel9.add(btnEliminarCliente);
        btnEliminarCliente.setBounds(139, 315, 102, 33);

        btnNuevoCliente.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnNuevoCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/nuevo.png"))); // NOI18N
        btnNuevoCliente.setText("   Agregar");
        btnNuevoCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnNuevoCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoClienteActionPerformed(evt);
            }
        });
        jPanel9.add(btnNuevoCliente);
        btnNuevoCliente.setBounds(139, 354, 103, 32);

        btnMostrar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/icons8-ojo-cerrado-32.png"))); // NOI18N
        btnMostrar2.setText("  Mostrar Base de datos");
        btnMostrar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrar2ActionPerformed(evt);
            }
        });
        jPanel9.add(btnMostrar2);
        btnMostrar2.setBounds(19, 258, 207, 39);

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17.setText("Apellido Paterno:");
        jPanel9.add(jLabel17);
        jLabel17.setBounds(5, 64, 103, 15);
        jPanel9.add(txtApellidoP);
        txtApellidoP.setBounds(114, 65, 129, 21);

        jLabel44.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel44.setText("Apellido Materno:");
        jPanel9.add(jLabel44);
        jLabel44.setBounds(5, 108, 106, 15);
        jPanel9.add(txtApellidoM);
        txtApellidoM.setBounds(114, 104, 129, 22);

        jLabel46.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel46.setText("Correo:");
        jPanel9.add(jLabel46);
        jLabel46.setBounds(5, 182, 45, 15);

        txtCorreoCli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoCliActionPerformed(evt);
            }
        });
        jPanel9.add(txtCorreoCli);
        txtCorreoCli.setBounds(53, 178, 190, 22);

        jPanel3.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 250, 400));

        jTabbedPane1.addTab("2", jPanel3);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TableProveedor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "ApellidoPaterno", "ApellidoMaterno", "Telefono", "Direccion"
            }
        ));
        TableProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableProveedorMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(TableProveedor);
        if (TableProveedor.getColumnModel().getColumnCount() > 0) {
            TableProveedor.getColumnModel().getColumn(0).setPreferredWidth(20);
            TableProveedor.getColumnModel().getColumn(1).setPreferredWidth(40);
            TableProveedor.getColumnModel().getColumn(2).setPreferredWidth(100);
            TableProveedor.getColumnModel().getColumn(3).setPreferredWidth(50);
            TableProveedor.getColumnModel().getColumn(4).setPreferredWidth(80);
        }

        jPanel4.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(355, 27, 500, 380));

        jPanel10.setBackground(new java.awt.Color(255, 204, 204));
        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Nuevo Proveedor"));

        jLabel18.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel18.setText("Nombre:");

        jLabel19.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel19.setText("Teléfono:");

        jLabel20.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel20.setText("Dirección:");

        txtDireccionProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionProveedorActionPerformed(evt);
            }
        });

        btnguardarProveedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/GuardarTodo.png"))); // NOI18N
        btnguardarProveedor.setMnemonic(' ');
        btnguardarProveedor.setText("  Guardar");
        btnguardarProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguardarProveedorActionPerformed(evt);
            }
        });

        btnEditarProveedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actualizar (2).png"))); // NOI18N
        btnEditarProveedor.setText("Modificar");
        btnEditarProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarProveedorActionPerformed(evt);
            }
        });

        btnNuevoProveedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/nuevo.png"))); // NOI18N
        btnNuevoProveedor.setText("   Nuevo");
        btnNuevoProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoProveedorActionPerformed(evt);
            }
        });

        btnEliminarProveedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/eliminar.png"))); // NOI18N
        btnEliminarProveedor.setText("   Eliminar");
        btnEliminarProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarProveedorActionPerformed(evt);
            }
        });

        btnMostrar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/icons8-ojo-cerrado-32.png"))); // NOI18N
        btnMostrar1.setText("  Mostrar Base de datos");
        btnMostrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrar1ActionPerformed(evt);
            }
        });

        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel39.setText("Apellido Paterno:");

        jLabel42.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel42.setText("Apellido Materno:");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtDireccionProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtNombreproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel39)
                        .addGap(62, 62, 62)
                        .addComponent(txtApellidoPaterno))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel42)
                        .addGap(62, 62, 62)
                        .addComponent(txtApellidoMaterno))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel19)
                        .addGap(110, 110, 110)
                        .addComponent(txtTelefonoProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnguardarProveedor)
                                    .addComponent(btnEditarProveedor))
                                .addGap(74, 74, 74)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnEliminarProveedor, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btnNuevoProveedor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(btnMostrar1, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(19, 19, 19))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(txtNombreproveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtApellidoPaterno, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel39))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel42)
                    .addComponent(txtApellidoMaterno, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(txtTelefonoProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(txtDireccionProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnMostrar1)
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminarProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnguardarProveedor))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNuevoProveedor)
                    .addComponent(btnEditarProveedor))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 330, 390));

        jTabbedPane1.addTab("3", jPanel4);

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TableProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Codigo", "Categoria", "Descripcion", "Proveedor", "Cantidad", "Precio"
            }
        ));
        TableProducto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableProductoMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(TableProducto);
        if (TableProducto.getColumnModel().getColumnCount() > 0) {
            TableProducto.getColumnModel().getColumn(0).setPreferredWidth(20);
            TableProducto.getColumnModel().getColumn(1).setPreferredWidth(50);
            TableProducto.getColumnModel().getColumn(2).setPreferredWidth(100);
            TableProducto.getColumnModel().getColumn(3).setPreferredWidth(60);
            TableProducto.getColumnModel().getColumn(4).setPreferredWidth(40);
            TableProducto.getColumnModel().getColumn(5).setPreferredWidth(50);
        }

        jPanel5.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 30, 580, 390));

        jPanel11.setBackground(new java.awt.Color(255, 204, 255));
        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder("Nuevo Producto"));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel22.setText("Código:");
        jPanel11.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 62, -1, -1));
        jPanel11.add(txtCodigoPro, new org.netbeans.lib.awtextra.AbsoluteConstraints(101, 58, 130, -1));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel24.setText("Cantidad:");
        jPanel11.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 203, -1, -1));
        jPanel11.add(txtCantPro, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 195, 130, 30));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel25.setText("Precio:");
        jPanel11.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 239, -1, -1));

        txtPrecioPro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPrecioProKeyTyped(evt);
            }
        });
        jPanel11.add(txtPrecioPro, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 231, 130, 30));

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel26.setText("Proveedor:");
        jPanel11.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 165, -1, -1));

        btnGuardarpro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/GuardarTodo.png"))); // NOI18N
        btnGuardarpro.setText("   Guardar");
        btnGuardarpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarproActionPerformed(evt);
            }
        });
        jPanel11.add(btnGuardarpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 317, -1, -1));

        btnEditarpro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actualizar (2).png"))); // NOI18N
        btnEditarpro.setText("Modificar");
        btnEditarpro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarproActionPerformed(evt);
            }
        });
        jPanel11.add(btnEditarpro, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 357, 111, -1));

        btnEliminarPro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/eliminar.png"))); // NOI18N
        btnEliminarPro.setText("   Eliminar");
        btnEliminarPro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarProActionPerformed(evt);
            }
        });
        jPanel11.add(btnEliminarPro, new org.netbeans.lib.awtextra.AbsoluteConstraints(128, 317, -1, 33));

        btnNuevoPro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/nuevo.png"))); // NOI18N
        btnNuevoPro.setText("   Nuevo");
        btnNuevoPro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoProActionPerformed(evt);
            }
        });
        jPanel11.add(btnNuevoPro, new org.netbeans.lib.awtextra.AbsoluteConstraints(128, 357, 109, -1));

        btnMostrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/icons8-ojo-cerrado-32.png"))); // NOI18N
        btnMostrar.setText("  Mostrar Base de datos");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });
        jPanel11.add(btnMostrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 267, 235, -1));

        jPanel11.add(cbxListaPro, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 161, 130, -1));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel23.setText("Descripción:");
        jPanel11.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 127, -1, -1));
        jPanel11.add(txtDesPro, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 119, 130, 30));

        jLabel43.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel43.setText("Nombre:");
        jPanel11.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 28, -1, -1));
        jPanel11.add(txtNombreProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, 130, 20));

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel27.setText("Categoria");
        jPanel11.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 92, -1, -1));

        cbxCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mascotas", "Cocina", "Electronica", "Bolsos", "Juguetes", "Peluches", "Papeleria", "Belleza" }));
        jPanel11.add(cbxCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 130, -1));

        jPanel5.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 250, 400));

        jTabbedPane1.addTab("4", jPanel5);

        jPanel6.setBackground(new java.awt.Color(255, 255, 102));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TableVentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Ciente", "Vendedor", "Total", "Fecha"
            }
        ));
        TableVentas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableVentasMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(TableVentas);
        if (TableVentas.getColumnModel().getColumnCount() > 0) {
            TableVentas.getColumnModel().getColumn(0).setPreferredWidth(20);
            TableVentas.getColumnModel().getColumn(1).setPreferredWidth(60);
            TableVentas.getColumnModel().getColumn(2).setPreferredWidth(60);
            TableVentas.getColumnModel().getColumn(3).setPreferredWidth(60);
        }

        jPanel6.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, 766, 310));

        btnPdfVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/pdf.png"))); // NOI18N
        btnPdfVentas.setText("   Generar PDF");
        btnPdfVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPdfVentasActionPerformed(evt);
            }
        });
        jPanel6.add(btnPdfVentas, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, -1, -1));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("Historial Ventas");
        jPanel6.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, 280, -1));

        btnMostrar3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/icons8-ojo-cerrado-32.png"))); // NOI18N
        btnMostrar3.setText("  Mostrar Base de datos");
        btnMostrar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrar3ActionPerformed(evt);
            }
        });
        jPanel6.add(btnMostrar3, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 30, -1, -1));

        btnEliminarVenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/eliminar.png"))); // NOI18N
        btnEliminarVenta.setText("   Eliminar");
        btnEliminarVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarVentaActionPerformed(evt);
            }
        });
        jPanel6.add(btnEliminarVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, -1, -1));

        jTabbedPane1.addTab("5", jPanel6);

        jPanel7.setBackground(new java.awt.Color(255, 227, 206));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Personal"));

        btnMostrar4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/icons8-ojo-cerrado-32.png"))); // NOI18N
        btnMostrar4.setText("  Mostrar Base de datos");
        btnMostrar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrar4ActionPerformed(evt);
            }
        });

        btnGuardarPersonal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/GuardarTodo.png"))); // NOI18N
        btnGuardarPersonal.setText("   Guardar");
        btnGuardarPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarPersonalActionPerformed(evt);
            }
        });

        btnEliminarPersonal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/eliminar.png"))); // NOI18N
        btnEliminarPersonal.setText("   Eliminar");
        btnEliminarPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarPersonalActionPerformed(evt);
            }
        });

        btnNuevoPersonal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/nuevo.png"))); // NOI18N
        btnNuevoPersonal.setText("   Nuevo");
        btnNuevoPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoPersonalActionPerformed(evt);
            }
        });

        btnEditarPersonal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actualizar (2).png"))); // NOI18N
        btnEditarPersonal.setText("Modificar");
        btnEditarPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarPersonalActionPerformed(evt);
            }
        });

        jLabel47.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel47.setText("Nombre:");

        txtNombrePersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombrePersonalActionPerformed(evt);
            }
        });

        jLabel48.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel48.setText("Apellido Paterno:");

        jLabel49.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel49.setText("Apellido Materno:");

        jLabel51.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel51.setText("Contraseña:");

        jLabel52.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel52.setText("Correo:");

        txtCorreoPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoPersonalActionPerformed(evt);
            }
        });

        jLabel59.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel59.setText("Cargo:");

        iconContraseña.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/cyber-security.png"))); // NOI18N
        iconContraseña.setText("jLabel8");
        iconContraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                iconContraseñaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                iconContraseñaMouseReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel48)
                            .addComponent(jLabel49)
                            .addComponent(jLabel59)
                            .addComponent(jLabel47))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbxCargoPersonal, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtApellidoMPersonal, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtApellidoPPersonal, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtNombrePersonal, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel52)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtCorreoPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel51)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(iconContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(passContraPersonal))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(btnEditarPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnNuevoPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(btnGuardarPersonal)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnEliminarPersonal))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(btnMostrar4)))))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel47)
                    .addComponent(txtNombrePersonal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtApellidoPPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel48))
                .addGap(14, 14, 14)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtApellidoMPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel49))
                .addGap(10, 10, 10)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel59)
                    .addComponent(cbxCargoPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCorreoPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel52))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel51)
                    .addComponent(passContraPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(iconContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnMostrar4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminarPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGuardarPersonal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNuevoPersonal)
                    .addComponent(btnEditarPersonal))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        TablePersonal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "ApellidoPaterno", "ApellidoMaterno", "Correo", "Contraseña", "Cargo"
            }
        ));
        TablePersonal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablePersonalMouseClicked(evt);
            }
        });
        TableAdmin.setViewportView(TablePersonal);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(TableAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 559, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(TableAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab5", jPanel2);

        jPanel13.setBackground(new java.awt.Color(199, 182, 206));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Verdana", 1, 60)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 249, 240));
        jLabel2.setText("INICIO");

        jLabel3.setFont(new java.awt.Font("Simplified Arabic", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Mendez Garcia Angel de Jesus");

        jLabel4.setFont(new java.awt.Font("Simplified Arabic", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Perez Jimenez Santiago Enmanuel");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(0, 257, Short.MAX_VALUE)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(212, 212, 212))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(299, 299, 299))))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(jLabel2)
                .addGap(78, 78, 78)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(98, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab7", jPanel13);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 95, 860, 460));

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));

        tipo1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/ito.png"))); // NOI18N

        btnClientes.setBackground(new java.awt.Color(51, 0, 0));
        btnClientes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnClientes.setForeground(new java.awt.Color(255, 255, 255));
        btnClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Clientes.png"))); // NOI18N
        btnClientes.setText("Clientes");
        btnClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClientesActionPerformed(evt);
            }
        });

        btnProveedor.setBackground(new java.awt.Color(51, 0, 0));
        btnProveedor.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnProveedor.setForeground(new java.awt.Color(255, 255, 255));
        btnProveedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/proveedor.png"))); // NOI18N
        btnProveedor.setText("Proveedor");
        btnProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProveedorActionPerformed(evt);
            }
        });

        btnProductos.setBackground(new java.awt.Color(51, 0, 0));
        btnProductos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnProductos.setForeground(new java.awt.Color(255, 255, 255));
        btnProductos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/producto.png"))); // NOI18N
        btnProductos.setText("Productos");
        btnProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProductosActionPerformed(evt);
            }
        });

        btnVentas.setBackground(new java.awt.Color(51, 0, 0));
        btnVentas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVentas.setForeground(new java.awt.Color(255, 255, 255));
        btnVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/compras.png"))); // NOI18N
        btnVentas.setText("Ventas");
        btnVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVentasActionPerformed(evt);
            }
        });

        btnPersonal.setBackground(new java.awt.Color(51, 0, 0));
        btnPersonal.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnPersonal.setForeground(new java.awt.Color(255, 255, 255));
        btnPersonal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/user.png"))); // NOI18N
        btnPersonal.setText("Personal");
        btnPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPersonalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addGap(74, 74, 74)
                                .addComponent(tipo1))
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(LabelVendedor))
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jLabel38)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                        .addGap(0, 25, Short.MAX_VALUE)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnClientes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnProveedor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnProductos, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnVentas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnPersonal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(jLabel38)
                .addGap(16, 16, 16)
                .addComponent(LabelVendedor)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tipo1)
                .addGap(50, 50, 50)
                .addComponent(btnClientes)
                .addGap(18, 18, 18)
                .addComponent(btnProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnProductos)
                .addGap(18, 18, 18)
                .addComponent(btnVentas)
                .addGap(18, 18, 18)
                .addComponent(btnPersonal)
                .addContainerGap(101, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 210, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPdfVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPdfVentasActionPerformed
        int filaSeleccionada = TableVentas.getSelectedRow();
        if (filaSeleccionada != -1) 
        {
            String idVentaStr = TableVentas.getValueAt(filaSeleccionada, 0).toString(); // columna 0 = id_venta
            int idVenta = Integer.parseInt(idVentaStr);
            String rutaPDF = CC.generarRutaPDF("Venta", String.valueOf(idVenta));
            CBV.generarPDFVenta(idVenta);
            File archivoPDF = new File(rutaPDF);
            if (archivoPDF.exists()) 
            {
                try 
                {
                    Desktop.getDesktop().open(archivoPDF);
                } 
                catch (IOException e) 
                {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "No se pudo abrir el PDF automáticamente.");
                }
            } 
            else 
            {
                JOptionPane.showMessageDialog(null, "El archivo PDF no fue encontrado.");
            }
        } 
        else 
        {
            JOptionPane.showMessageDialog(null, "Seleccione una venta de la tabla.");
        }
    }//GEN-LAST:event_btnPdfVentasActionPerformed

    private void TableVentasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableVentasMouseClicked
        // TODO add your handling code here:
        int fila = TableVentas.rowAtPoint(evt.getPoint());
    }//GEN-LAST:event_TableVentasMouseClicked

    private void TableProductoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableProductoMouseClicked
        // TODO add your handling code here:
        btnEditarpro.setEnabled(true);
        btnEliminarPro.setEnabled(true);
        btnGuardarpro.setEnabled(true);
        int fila = TableProducto.rowAtPoint(evt.getPoint());
        txtNombreProducto.setText(TableProducto.getValueAt(fila, 0).toString());
        txtCodigoPro.setText(TableProducto.getValueAt(fila, 1).toString());
        cbxCategoria.setSelectedItem(TableProducto.getValueAt(fila, 2).toString());
        cbxListaPro.setSelectedItem(TableProducto.getValueAt(fila, 4).toString());
        txtDesPro.setText(TableProducto.getValueAt(fila, 3).toString());
        txtCantPro.setText(TableProducto.getValueAt(fila, 5).toString());
        txtPrecioPro.setText(TableProducto.getValueAt(fila, 6).toString());
    }//GEN-LAST:event_TableProductoMouseClicked

    private void btnEliminarProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarProveedorActionPerformed
        // TODO add your handling code here:
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas eliminar este Proveedor?",
                "Confirmar eliminacion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            EliminarProveedor();
        }
    }//GEN-LAST:event_btnEliminarProveedorActionPerformed

    private void btnNuevoProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoProveedorActionPerformed
        // TODO add your handling code here:
        LimpiarProveedor();
        btnEditarProveedor.setEnabled(false);
        btnEliminarProveedor.setEnabled(false);
        btnguardarProveedor.setEnabled(true);
    }//GEN-LAST:event_btnNuevoProveedorActionPerformed

    private void btnEditarProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarProveedorActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = TableProveedor.getSelectedRow();
        String nombreOriginal = (String) TableProveedor.getValueAt(filaSeleccionada, 0);
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas modificar este Proveedor?",
                "Confirmar modificacion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            if (!"".equals(txtNombreproveedor.getText()) || !"".equals(txtTelefonoProveedor.getText()) || !"".equals(txtDireccionProveedor.getText()) || !"".equals(txtApellidoPaterno.getText()) || !"".equals(txtApellidoMaterno.getText())) 
            {
                if (CBP.ModificarProveedorPorNombre(nombreOriginal, txtNombreproveedor.getText(), txtApellidoPaterno.getText(), txtApellidoMaterno.getText(), txtTelefonoProveedor.getText(), txtDireccionProveedor.getText()))
                {
                    LimpiarTable();
                    LimpiarProveedor();
                    LlenarTablaProveedores ();
                    btnEditarProveedor.setEnabled(false);
                    btnEliminarProveedor.setEnabled(false);
                    btnguardarProveedor.setEnabled(true);
                    JOptionPane.showMessageDialog(null, "Proveedor Modificado");
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Error al modificar el Proveedor");
                }
            }
        }
    }//GEN-LAST:event_btnEditarProveedorActionPerformed

    private void btnguardarProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguardarProveedorActionPerformed
        // TODO add your handling code here:
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas guardar este Proveedor?",
                "Confirmar registro",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            if (!"".equals(txtNombreproveedor.getText()) || !"".equals(txtTelefonoProveedor.getText()) || !"".equals(txtDireccionProveedor.getText()) || !"".equals(txtApellidoPaterno.getText()) ||"".equals(txtApellidoMaterno.getText())) 
            {
                if (CBP.InsertarProveedor(txtNombreproveedor.getText(), txtApellidoPaterno.getText(), txtApellidoMaterno.getText(), txtTelefonoProveedor.getText(), txtDireccionProveedor.getText()))
                {
                    JOptionPane.showMessageDialog(null, "Proveedor Registrado");
                    LimpiarTable();
                    LimpiarProveedor();
                    btnEditarProveedor.setEnabled(false);
                    btnEliminarProveedor.setEnabled(false);
                    btnguardarProveedor.setEnabled(true); 
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Errror al registrar al Proveedor");
                }
            } 
            else 
            {
                JOptionPane.showMessageDialog(null, "Los campos esta vacios");
            }
        }
    }//GEN-LAST:event_btnguardarProveedorActionPerformed

    private void TableProveedorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableProveedorMouseClicked
        // TODO add your handling code here:
        btnEditarProveedor.setEnabled(true);
        btnEliminarProveedor.setEnabled(true);
        btnguardarProveedor.setEnabled(false);
        int fila = TableProveedor.rowAtPoint(evt.getPoint());
        txtNombreproveedor.setText(TableProveedor.getValueAt(fila, 0).toString());
        txtApellidoPaterno.setText(TableProveedor.getValueAt(fila, 1).toString());
        txtApellidoMaterno.setText(TableProveedor.getValueAt(fila, 2).toString());
        txtTelefonoProveedor.setText(TableProveedor.getValueAt(fila, 3).toString());
        txtDireccionProveedor.setText(TableProveedor.getValueAt(fila, 4).toString());
    }//GEN-LAST:event_TableProveedorMouseClicked

    private void TableClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableClienteMouseClicked
        // TODO add your handling code here:
        btnEditarCliente.setEnabled(true);
        btnEliminarCliente.setEnabled(true);
        btnGuardarCliente.setEnabled(false);
        int fila = TableCliente.rowAtPoint(evt.getPoint());
        txtNombreCliente.setText(TableCliente.getValueAt(fila, 0).toString());
        txtApellidoP.setText(TableCliente.getValueAt(fila, 1).toString());
        txtApellidoM.setText(TableCliente.getValueAt(fila, 2).toString());
        txtTelefonoCliente.setText(TableCliente.getValueAt(fila, 3).toString());
        txtDirecionCliente.setText(TableCliente.getValueAt(fila, 5).toString());
        txtCorreoCli.setText(TableCliente.getValueAt(fila, 4).toString());
    }//GEN-LAST:event_TableClienteMouseClicked

    private void btnNuevoClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoClienteActionPerformed
        // TODO add your handling code here:
        LimpiarCliente();
        btnEditarCliente.setEnabled(false);
        btnEliminarCliente.setEnabled(false);
        btnGuardarCliente.setEnabled(true);
    }//GEN-LAST:event_btnNuevoClienteActionPerformed

    private void btnEliminarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarClienteActionPerformed
        // TODO add your handling code here:
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas eliminar este Cliente?",
                "Confirmar eliminacion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            EliminarCliente ();
            LlenarTablaClientes ();
        }
    }//GEN-LAST:event_btnEliminarClienteActionPerformed

    private void btnEditarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarClienteActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = TableCliente.getSelectedRow();
        String nombreOriginal = (String) TableCliente.getValueAt(filaSeleccionada, 0);
        String apePOri = (String) TableCliente.getValueAt(filaSeleccionada, 1);
        String apeMOri = (String) TableCliente.getValueAt(filaSeleccionada, 2);
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas modificar este Cliente?",
                "Confirmar modificacion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            if (!"".equals(txtNombreCliente.getText()) || !"".equals(txtApellidoP.getText()) || !"".equals(txtApellidoM.getText()) || !"".equals(txtTelefonoCliente.getText()) || !"".equals(txtDirecionCliente.getText()) || !"".equals(txtCorreoCli.getText())) 
            {
                if (Lector.VerificarCorreo(txtCorreoCli.getText()))
                {
                    if (CBC.ModificarCliente(nombreOriginal, apePOri, apeMOri, txtNombreCliente.getText(), txtApellidoP.getText(), txtApellidoM.getText(), txtTelefonoCliente.getText(), txtCorreoCli.getText(), txtDirecionCliente.getText()))
                    {
                        LimpiarTable();
                        LimpiarCliente ();
                        LlenarTablaClientes ();
                        btnEditarCliente.setEnabled(false);
                        btnEliminarCliente.setEnabled(false);
                        btnGuardarCliente.setEnabled(true);
                        JOptionPane.showMessageDialog(null, "Cliente Modificado");
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "Error al modificar al Cliente");
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Error el correo no tiene el formato deseado"); 
                }
            } 
            else 
            {
                JOptionPane.showMessageDialog(null, "Los campos estan vacios");
            }
        }
    }//GEN-LAST:event_btnEditarClienteActionPerformed

    private void btnGuardarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarClienteActionPerformed
        // TODO add your handling code here:
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas guardar este Cliente?",
                "Confirmar registro",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            if (!"".equals(txtNombreCliente.getText()) || !"".equals(txtApellidoP.getText()) || !"".equals(txtApellidoM.getText()) || !"".equals(txtTelefonoCliente.getText()) || !"".equals(txtDirecionCliente.getText()) || !"".equals(txtCorreoCli.getText())) 
            {
                if (Lector.VerificarCorreo(txtCorreoCli.getText()))
                {
                    if (CBC.InsertarCliente(txtNombreCliente.getText(), txtApellidoP.getText(), txtApellidoM.getText(), txtTelefonoCliente.getText(),txtCorreoCli.getText() ,txtDirecionCliente.getText()))
                    {
                        LimpiarTable();
                        LimpiarCliente();
                        btnEditarCliente.setEnabled(false);
                        btnEliminarCliente.setEnabled(false);
                        btnGuardarCliente.setEnabled(true);
                        JOptionPane.showMessageDialog(null, "Cliente Registrado");
                    }
                    else
                    {
                       JOptionPane.showMessageDialog(null, "Error al registrar al Cliente"); 
                    }
                }
                else
                {
                   JOptionPane.showMessageDialog(null, "Error el correo no tiene el formato correcto"); 
                }
            } 
            else 
            {
                JOptionPane.showMessageDialog(null, "Los campos estan vacios");
            }
        }
    }//GEN-LAST:event_btnGuardarClienteActionPerformed

    private void txtDireccionProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionProveedorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDireccionProveedorActionPerformed

    private void btnMostrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrar1ActionPerformed
        LlenarTablaProveedores ();
    }//GEN-LAST:event_btnMostrar1ActionPerformed

    private void btnMostrar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrar2ActionPerformed
        LlenarTablaClientes ();
    }//GEN-LAST:event_btnMostrar2ActionPerformed

    private void btnMostrar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrar3ActionPerformed
        // TODO add your handling code here:
        LlenarTablaVentas ();
    }//GEN-LAST:event_btnMostrar3ActionPerformed

    private void btnEliminarVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarVentaActionPerformed
        // TODO add your handling code here:
        EliminarVentas ();
    }//GEN-LAST:event_btnEliminarVentaActionPerformed

    private void btnNuevoProActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoProActionPerformed
        // TODO add your handling code here:
        LimpiarProductos ();
        btnEditarpro.setEnabled(false);
        btnEliminarPro.setEnabled(false);
        btnGuardarpro.setEnabled(true);
    }//GEN-LAST:event_btnNuevoProActionPerformed

    private void btnEliminarProActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarProActionPerformed
        // TODO add your handling code here:
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas eliminar este Producto?",
                "Confirmar eliminacion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            EliminarProductos ();
        }
    }//GEN-LAST:event_btnEliminarProActionPerformed

    private void btnEditarproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarproActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = TableProducto.getSelectedRow();
        String nombreOriginal = (String) TableProducto.getValueAt(filaSeleccionada, 0);
        String codigoStr = (String) TableProducto.getValueAt(filaSeleccionada, 1);
        int codigoOriginal = Integer.parseInt(codigoStr);
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas modificar al Producto?",
                "Confirmar modificacion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            if (!"".equals(txtNombreProducto.getText()) || !"".equals(txtCodigoPro.getText()) || !"".equals(cbxCategoria.getSelectedIndex()) || !"".equals(txtDesPro.getText()) || !"".equals(cbxListaPro.getSelectedItem()) || !"".equals(txtCantPro.getText()) || !"".equals(txtPrecioPro.getText()))
            {
                if (CBPr.ModificarProducto (nombreOriginal, codigoOriginal, txtNombreProducto.getText(), Integer.parseInt(txtCodigoPro.getText()), (String) cbxCategoria.getSelectedItem(), txtDesPro.getText(), (String) cbxListaPro.getSelectedItem(), Integer.parseInt(txtCantPro.getText()), Double.parseDouble(txtPrecioPro.getText())))
                {
                    LimpiarTable();
                    LimpiarProductos();
                    Categoria_Seleccionada = (String) TableProducto.getValueAt(filaSeleccionada, 2);
                    LlenarTablaProductos (CBPr.ListarProductosTipo(Categoria_Seleccionada));
                    cbxListaPro.removeAllItems();
                    btnEditarpro.setEnabled(false);
                    btnEliminarPro.setEnabled(false);
                    btnGuardarpro.setEnabled(true);
                    JOptionPane.showMessageDialog(null, "Producto Modificado");
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Error al modificar el Producto");
                }
            }
        }
    }//GEN-LAST:event_btnEditarproActionPerformed

    private void btnGuardarproActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarproActionPerformed
        // TODO add your handling code here:
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas añadir un Producto?",
                "Confirmar registro",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            if (!"".equals(txtNombreProducto.getText()) || !"".equals(txtCodigoPro.getText()) || !"".equals(cbxCategoria.getSelectedIndex()) || !"".equals(txtDesPro.getText()) || !"".equals(cbxListaPro.getSelectedItem()) || !"".equals(txtCantPro.getText()) || !"".equals(txtPrecioPro.getText()))
            {
                if (CBPr.InsertarProducto(txtNombreProducto.getText(), Integer.parseInt(txtCodigoPro.getText()), (String) cbxCategoria.getSelectedItem(), txtDesPro.getText(), (String) cbxListaPro.getSelectedItem(), Integer.parseInt(txtCantPro.getText()), Double.parseDouble(txtPrecioPro.getText())))
                {
                    JOptionPane.showMessageDialog(null, "Productos Registrado");
                    LimpiarTable();
                    LimpiarProductos();
                    cbxListaPro.removeAllItems();
                    btnEditarpro.setEnabled(false);
                    btnEliminarPro.setEnabled(false);
                    btnGuardarpro.setEnabled(true);
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Error al registrar el Producto");
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Los campos estan vacios");
            }
        }
    }//GEN-LAST:event_btnGuardarproActionPerformed

    private void txtPrecioProKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPrecioProKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecioProKeyTyped

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        JPanel panelCategoria = new JPanel();
        panelCategoria.setLayout(new BoxLayout(panelCategoria, BoxLayout.Y_AXIS));
        panelCategoria.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JLabel lblTitulo = new JLabel("Escoge la categoria que quieras ver:");
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        JComboBox<String> comboCategoria= new JComboBox<>();
        comboCategoria.setAlignmentX(Component.LEFT_ALIGNMENT);
        comboCategoria.addItem("Todas");
        // Cargar cargos desde la base de datos
        List<String> cargos = CBPr.CategoriasDisponibles();
        for (String cargo : cargos) 
        {
            comboCategoria.addItem(cargo);
        }
        JLabel lblAdvertencia = new JLabel("");
        lblAdvertencia.setForeground(Color.RED);
        lblAdvertencia.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Botón aceptar
        JButton btnAceptar = new JButton("Aceptar");
        // Lo centramos horizontalmente
        btnAceptar.setAlignmentX(Component.CENTER_ALIGNMENT);
        // Crear el diálogo personalizado
        JDialog dialog = new JDialog((Frame) null, "Filtrar Categorias", true);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setLayout(new BorderLayout());
        // Acción del botón aceptar
        btnAceptar.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                String seleccionado = (String) comboCategoria.getSelectedItem();
                if (seleccionado == null || seleccionado.isEmpty()) 
                {
                    lblAdvertencia.setText("No has escogido ningúna categoria.");
                    return;
                }
                lblAdvertencia.setText(""); // Limpiar advertencia
                // Actualiza tu tabla existente
                List<String[]> datos;
                if (seleccionado.equals("Todas")) 
                {
                    datos = CBPr.ListarProductos();
                } 
                else 
                {
                    datos = CBPr.ListarProductosTipo(seleccionado);
                }
                LlenarTablaProductos(datos);
                dialog.dispose(); // Cierra el panel después de aceptar
            }
        });
        // Agregar componentes al panel
        panelCategoria.add(lblTitulo);
        panelCategoria.add(Box.createVerticalStrut(10));
        panelCategoria.add(comboCategoria);
        panelCategoria.add(Box.createVerticalStrut(10));
        panelCategoria.add(btnAceptar);
        panelCategoria.add(Box.createVerticalStrut(10));
        panelCategoria.add(lblAdvertencia);
        // Agregar panel al diálogo
        dialog.add(panelCategoria, BorderLayout.CENTER);
        dialog.pack();
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnMostrar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrar4ActionPerformed
        // TODO add your handling code here:
        JPanel panelCargo = new JPanel();
        panelCargo.setLayout(new BoxLayout(panelCargo, BoxLayout.Y_AXIS));
        panelCargo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JLabel lblTitulo = new JLabel("Escoge el cargo que quieras ver:");
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        JComboBox<String> comboCargos = new JComboBox<>();
        comboCargos.setAlignmentX(Component.LEFT_ALIGNMENT);
        comboCargos.addItem("Todas");
        // Cargar cargos desde la base de datos
        List<String> cargos = CBPe.CargosDisponibles();
        for (String cargo : cargos) 
        {
            comboCargos.addItem(cargo);
        }
        JLabel lblAdvertencia = new JLabel("");
        lblAdvertencia.setForeground(Color.RED);
        lblAdvertencia.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Botón aceptar
        JButton btnAceptar = new JButton("Aceptar");
        // Lo centramos horizontalmente
        btnAceptar.setAlignmentX(Component.CENTER_ALIGNMENT);
        // Crear el diálogo personalizado
        JDialog dialog = new JDialog((Frame) null, "Filtrar Personal", true);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setLayout(new BorderLayout());
        // Acción del botón aceptar
        btnAceptar.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                String seleccionado = (String) comboCargos.getSelectedItem();
                if (seleccionado == null || seleccionado.isEmpty()) 
                {
                    lblAdvertencia.setText("No has escogido ningún cargo.");
                    return;
                }
                lblAdvertencia.setText(""); // Limpiar advertencia
                // Actualiza tu tabla existente
                List<String[]> datos;
                if (seleccionado.equals("Todas")) 
                {
                    datos = CBPe.ObtenerPersonal();
                } 
                else 
                {
                    datos = CBPe.ObtenerPersonalCargo(seleccionado);
                }
                LlenarTablaPersonal(datos);
                dialog.dispose(); // Cierra el panel después de aceptar
            }
        });
        // Agregar componentes al panel
        panelCargo.add(lblTitulo);
        panelCargo.add(Box.createVerticalStrut(10));
        panelCargo.add(comboCargos);
        panelCargo.add(Box.createVerticalStrut(10));
        panelCargo.add(btnAceptar);
        panelCargo.add(Box.createVerticalStrut(10));
        panelCargo.add(lblAdvertencia);
        // Agregar panel al diálogo
        dialog.add(panelCargo, BorderLayout.CENTER);
        dialog.pack();
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
    }//GEN-LAST:event_btnMostrar4ActionPerformed

    private void btnGuardarPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarPersonalActionPerformed
        // TODO add your handling code here:
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas añadir un Personal?",
                "Confirmar registro",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            if (!"".equals(cbxCargoPersonal.getSelectedIndex()) || !"".equals(txtNombrePersonal.getText()) || !"".equals(txtApellidoPPersonal.getText()) || !"".equals(new String (passContraPersonal.getPassword())) || !"".equals(txtCorreoPersonal.getText()))
            {
                if (Lector.VerificarCorreo(txtCorreoPersonal.getText()))
                {
                    if (CBPe.InsertarPersonal (txtNombrePersonal.getText(), txtApellidoPPersonal.getText(), txtApellidoMPersonal.getText(), new String (passContraPersonal.getPassword()), txtCorreoPersonal.getText(), (String) cbxCargoPersonal.getSelectedItem()))
                    {
                        LimpiarTable();
                        LimpiarPersonal ();
                        btnEditarPersonal.setEnabled(false);
                        btnEliminarPersonal.setEnabled(false);
                        btnGuardarPersonal.setEnabled(true);
                        JOptionPane.showMessageDialog(null, "Personal registrado correctamente");
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "Error al registrar al Personal");
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Error el correo no tiene el formato deseado"); 
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Los campos estan vacios");
            }
        }
    }//GEN-LAST:event_btnGuardarPersonalActionPerformed

    private void btnEliminarPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarPersonalActionPerformed
        // TODO add your handling code here:
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas eliminar a un Personal?",
                "Confirmar eliminacion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            EliminarPersonal ();
        }       
    }//GEN-LAST:event_btnEliminarPersonalActionPerformed

    private void btnNuevoPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoPersonalActionPerformed
        // TODO add your handling code here:
        LimpiarPersonal ();
        txtApellidoPPersonal.setText("");
        txtApellidoMPersonal.setText("");
        btnEditarPersonal.setEnabled(false);
        btnEliminarPersonal.setEnabled(false);
        btnGuardarPersonal.setEnabled(true);
    }//GEN-LAST:event_btnNuevoPersonalActionPerformed

    private void btnEditarPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarPersonalActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = TablePersonal.getSelectedRow();
        String Cargo = (String) TablePersonal.getValueAt(filaSeleccionada, 5);
        String Correo = (String) TablePersonal.getValueAt(filaSeleccionada, 3);
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas modificar a un Personal?",
                "Confirmar modificacion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            if (!"".equals(txtNombrePersonal.getText()) || !"".equals(txtApellidoPPersonal.getText()) || !"".equals(txtApellidoMPersonal.getText()) || !"".equals(new String (passContraPersonal.getPassword())) || !"".equals(txtCorreoPersonal.getText()) || !"".equals(cbxCargoPersonal.getSelectedIndex()));
            {
                if (Lector.VerificarCorreo(txtCorreoPersonal.getText()))
                {
                    if (CBPe.ModificarPersonal(Correo, Cargo, txtNombrePersonal.getText(), txtApellidoPPersonal.getText(), txtApellidoMPersonal.getText(), new String (passContraPersonal.getPassword()),txtCorreoPersonal.getText(), (String) cbxCargoPersonal.getSelectedItem()))
                    {
                        LimpiarTable ();
                        LimpiarPersonal ();
                        btnEditarPersonal.setEnabled(false);
                        btnEliminarPersonal.setEnabled(false);
                        btnGuardarPersonal.setEnabled(true);
                        JOptionPane.showMessageDialog(null, "Personal Modificado");
                        Cargo_Seleccionada = (String) TablePersonal.getValueAt(filaSeleccionada, 5);
                        LlenarTablaPersonal (CBPe.ObtenerPersonalCargo(Cargo_Seleccionada));
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "Error al modificar al Personal");
                    }     
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Error el correo no tiene el formato deseado"); 
                }
            }
        }
    }//GEN-LAST:event_btnEditarPersonalActionPerformed

    private void TablePersonalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablePersonalMouseClicked
        // TODO add your handling code here:
        btnEditarPersonal.setEnabled(true);
        btnEliminarPersonal.setEnabled(true);
        btnGuardarPersonal.setEnabled(false);
        int fila = TablePersonal.rowAtPoint(evt.getPoint());
        txtNombrePersonal.setText(TablePersonal.getValueAt(fila, 0).toString());
        txtApellidoPPersonal.setText(TablePersonal.getValueAt(fila, 1).toString());
        txtApellidoMPersonal.setText(TablePersonal.getValueAt(fila, 2).toString());
        passContraPersonal.setText(TablePersonal.getValueAt(fila, 4).toString());
        txtCorreoPersonal.setText(TablePersonal.getValueAt(fila, 3).toString());
        cbxCargoPersonal.setSelectedItem(TablePersonal.getValueAt(fila, 5).toString());      
    }//GEN-LAST:event_TablePersonalMouseClicked

    private void btnClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClientesActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_btnClientesActionPerformed

    private void btnProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProveedorActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_btnProveedorActionPerformed

    private void btnProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProductosActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_btnProductosActionPerformed

    private void btnVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVentasActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_btnVentasActionPerformed

    private void btnPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPersonalActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_btnPersonalActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que deseas salir?",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (opcion == JOptionPane.YES_OPTION) 
        {
            Login lo = new Login ();
            lo.setVisible(true);
            dispose(); // Cierra la ventana
        }
    }//GEN-LAST:event_formWindowClosing

    private void txtCorreoCliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoCliActionPerformed
        // TODO add your handling code here:
        String NombreCliente = txtNombreCliente.getText() + " " + txtApellidoP.getText() + " " + txtApellidoM.getText();
        CC.generarRutaPDF("Verificacion", null);
        CC.crearPDFVerificacion(codigoEsperado, NombreCliente, txtCorreoCli.getText());
        try 
        {
            CC.EnviarCorreo(txtCorreoCli.getText(),"Verificacion de Correo");
        } 
        catch (MessagingException ex) 
        {
            Logger.getLogger(SistemaPrueba.class.getName()).log(Level.SEVERE, null, ex);
        }
        JPanel panelCodigo = new JPanel();
        panelCodigo.setLayout(new BoxLayout(panelCodigo, BoxLayout.Y_AXIS));
        panelCodigo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        // Etiqueta de instrucción
        JLabel lblInstruccion = new JLabel("Código enviado al correo:");
        lblInstruccion.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Campo de texto para ingresar el código
        JTextField txtCodigo = new JTextField();
        txtCodigo.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtCodigo.getPreferredSize().height));
        txtCodigo.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Etiqueta para código incorrecto
        JLabel lblCodigoIncorrecto = new JLabel("");
        lblCodigoIncorrecto.setForeground(Color.RED);
        lblCodigoIncorrecto.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Botón aceptar
        JButton btnAceptar = new JButton("Aceptar");
        btnAceptar.setAlignmentX(Component.CENTER_ALIGNMENT);
        // Botón para reenviar código
        JButton btnReenviar = new JButton("Enviar nuevo código");
        btnReenviar.setAlignmentX(Component.CENTER_ALIGNMENT);
        // Etiqueta para advertencias generales
        JLabel lblAdvertencia = new JLabel("");
        lblAdvertencia.setForeground(Color.RED);
        lblAdvertencia.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Crear el diálogo personalizado
        JDialog dialog = new JDialog((Frame) null, "Verificación", true);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setLayout(new BorderLayout());
        // Aquí reemplaza con tu código real esperado
        // Acción del botón aceptar
        btnAceptar.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                String codigoIngresado = txtCodigo.getText().trim();
                if (codigoIngresado.isEmpty()) 
                {
                    lblCodigoIncorrecto.setText("Por favor ingresa el código.");
                } 
                else if (!codigoIngresado.equals(codigoEsperado)) 
                {
                    lblCodigoIncorrecto.setText("Código incorrecto. Intenta nuevamente.");
                } 
                else 
                {
                    lblCodigoIncorrecto.setText("");
                    System.out.println("Código correcto: " + codigoIngresado);
                    dialog.dispose();
                }
            }
        });
        // Acción del botón reenviar código
        btnReenviar.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                codigoEsperado = Lector.GenerarCodigos();
                CC.generarRutaPDF("Verificacion", null);
                CC.crearPDFVerificacion(codigoEsperado, NombreCliente, txtCorreoCli.getText());
                try 
                {
                    CC.EnviarCorreo(txtCorreoCli.getText(),"Verificacion de Correo");
                } 
                catch (MessagingException ex) 
                {
                    Logger.getLogger(SistemaPrueba.class.getName()).log(Level.SEVERE, null, ex);
                }
                JOptionPane.showMessageDialog(dialog, "Se ha enviado un nuevo código al correo.");
            }
        });
        // Agregar componentes al panel
        panelCodigo.add(lblInstruccion);
        panelCodigo.add(Box.createVerticalStrut(10));
        panelCodigo.add(txtCodigo);
        panelCodigo.add(Box.createVerticalStrut(5));
        panelCodigo.add(lblCodigoIncorrecto);
        panelCodigo.add(Box.createVerticalStrut(10));
        panelCodigo.add(btnAceptar);
        panelCodigo.add(Box.createVerticalStrut(5));
        panelCodigo.add(btnReenviar);
        panelCodigo.add(Box.createVerticalStrut(10));
        panelCodigo.add(lblAdvertencia);
        // Agregar panel al diálogo
        dialog.add(panelCodigo, BorderLayout.CENTER);
        dialog.pack();
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
    }//GEN-LAST:event_txtCorreoCliActionPerformed

    private void txtCorreoPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoPersonalActionPerformed
        // TODO add your handling code here:
        String NombreCliente = txtNombreCliente.getText() + " " + txtApellidoP.getText() + " " + txtApellidoM.getText();
        CC.generarRutaPDF("Verificacion", null);
        CC.crearPDFVerificacion(codigoEsperado, NombreCliente, txtCorreoPersonal.getText());
        try 
        {
            CC.EnviarCorreo(txtCorreoPersonal.getText(),"Verificacion de Correo");
        } 
        catch (MessagingException ex) 
        {
            Logger.getLogger(SistemaPrueba.class.getName()).log(Level.SEVERE, null, ex);
        }
        JPanel panelCodigo = new JPanel();
        panelCodigo.setLayout(new BoxLayout(panelCodigo, BoxLayout.Y_AXIS));
        panelCodigo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        // Etiqueta de instrucción
        JLabel lblInstruccion = new JLabel("Código enviado al correo:");
        lblInstruccion.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Campo de texto para ingresar el código
        JTextField txtCodigo = new JTextField();
        txtCodigo.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtCodigo.getPreferredSize().height));
        txtCodigo.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Etiqueta para código incorrecto
        JLabel lblCodigoIncorrecto = new JLabel("");
        lblCodigoIncorrecto.setForeground(Color.RED);
        lblCodigoIncorrecto.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Botón aceptar
        JButton btnAceptar = new JButton("Aceptar");
        btnAceptar.setAlignmentX(Component.CENTER_ALIGNMENT);
        // Botón para reenviar código
        JButton btnReenviar = new JButton("Enviar nuevo código");
        btnReenviar.setAlignmentX(Component.CENTER_ALIGNMENT);
        // Etiqueta para advertencias generales
        JLabel lblAdvertencia = new JLabel("");
        lblAdvertencia.setForeground(Color.RED);
        lblAdvertencia.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Crear el diálogo personalizado
        JDialog dialog = new JDialog((Frame) null, "Verificación", true);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setLayout(new BorderLayout());
        // Aquí reemplaza con tu código real esperado
        // Acción del botón aceptar
        btnAceptar.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                String codigoIngresado = txtCodigo.getText().trim();
                if (codigoIngresado.isEmpty()) 
                {
                    lblCodigoIncorrecto.setText("Por favor ingresa el código.");
                } 
                else if (!codigoIngresado.equals(codigoEsperado)) 
                {
                    lblCodigoIncorrecto.setText("Código incorrecto. Intenta nuevamente.");
                } 
                else 
                {
                    lblCodigoIncorrecto.setText("");
                    System.out.println("Código correcto: " + codigoIngresado);
                    dialog.dispose();
                }
            }
        });
        // Acción del botón reenviar código
        btnReenviar.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                codigoEsperado = Lector.GenerarCodigos();
                CC.generarRutaPDF("Verificacion", null);
                CC.crearPDFVerificacion(codigoEsperado, NombreCliente, txtCorreoPersonal.getText());
                try 
                {
                    CC.EnviarCorreo(txtCorreoPersonal.getText(),"Verificacion de Correo");
                } 
                catch (MessagingException ex) 
                {
                    Logger.getLogger(SistemaPrueba.class.getName()).log(Level.SEVERE, null, ex);
                }
                JOptionPane.showMessageDialog(dialog, "Se ha enviado un nuevo código al correo.");
            }
        });
        // Agregar componentes al panel
        panelCodigo.add(lblInstruccion);
        panelCodigo.add(Box.createVerticalStrut(10));
        panelCodigo.add(txtCodigo);
        panelCodigo.add(Box.createVerticalStrut(5));
        panelCodigo.add(lblCodigoIncorrecto);
        panelCodigo.add(Box.createVerticalStrut(10));
        panelCodigo.add(btnAceptar);
        panelCodigo.add(Box.createVerticalStrut(5));
        panelCodigo.add(btnReenviar);
        panelCodigo.add(Box.createVerticalStrut(10));
        panelCodigo.add(lblAdvertencia);
        // Agregar panel al diálogo
        dialog.add(panelCodigo, BorderLayout.CENTER);
        dialog.pack();
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
    }//GEN-LAST:event_txtCorreoPersonalActionPerformed

    private void iconContraseñaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iconContraseñaMousePressed
        // TODO add your handling code here:
        passContraPersonal.setEchoChar((char)0);
    }//GEN-LAST:event_iconContraseñaMousePressed

    private void iconContraseñaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iconContraseñaMouseReleased
        // TODO add your handling code here:
        passContraPersonal.setEchoChar('*');
    }//GEN-LAST:event_iconContraseñaMouseReleased

    private void txtNombrePersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombrePersonalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombrePersonalActionPerformed

    /**
     * @param args the command line arguments
     */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LabelVendedor;
    private javax.swing.JScrollPane TableAdmin;
    private javax.swing.JTable TableCliente;
    private javax.swing.JTable TablePersonal;
    private javax.swing.JTable TableProducto;
    private javax.swing.JTable TableProveedor;
    private javax.swing.JTable TableVentas;
    private javax.swing.JButton btnClientes;
    private javax.swing.JButton btnEditarCliente;
    private javax.swing.JButton btnEditarPersonal;
    private javax.swing.JButton btnEditarProveedor;
    private javax.swing.JButton btnEditarpro;
    private javax.swing.JButton btnEliminarCliente;
    private javax.swing.JButton btnEliminarPersonal;
    private javax.swing.JButton btnEliminarPro;
    private javax.swing.JButton btnEliminarProveedor;
    private javax.swing.JButton btnEliminarVenta;
    private javax.swing.JButton btnGuardarCliente;
    private javax.swing.JButton btnGuardarPersonal;
    private javax.swing.JButton btnGuardarpro;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnMostrar1;
    private javax.swing.JButton btnMostrar2;
    private javax.swing.JButton btnMostrar3;
    private javax.swing.JButton btnMostrar4;
    private javax.swing.JButton btnNuevoCliente;
    private javax.swing.JButton btnNuevoPersonal;
    private javax.swing.JButton btnNuevoPro;
    private javax.swing.JButton btnNuevoProveedor;
    private javax.swing.JButton btnPdfVentas;
    private javax.swing.JButton btnPersonal;
    private javax.swing.JButton btnProductos;
    private javax.swing.JButton btnProveedor;
    private javax.swing.JButton btnVentas;
    private javax.swing.JButton btnguardarProveedor;
    private javax.swing.JComboBox<String> cbxCargoPersonal;
    private javax.swing.JComboBox<String> cbxCategoria;
    private javax.swing.JComboBox<String> cbxListaPro;
    private javax.swing.JLabel iconContraseña;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPasswordField passContraPersonal;
    private javax.swing.JLabel tipo;
    private javax.swing.JLabel tipo1;
    private javax.swing.JTextField txtApellidoM;
    private javax.swing.JTextField txtApellidoMPersonal;
    private javax.swing.JTextField txtApellidoMaterno;
    private javax.swing.JTextField txtApellidoP;
    private javax.swing.JTextField txtApellidoPPersonal;
    private javax.swing.JTextField txtApellidoPaterno;
    private javax.swing.JTextField txtCantPro;
    private javax.swing.JTextField txtCodigoPro;
    private javax.swing.JTextField txtCorreoCli;
    private javax.swing.JTextField txtCorreoPersonal;
    private javax.swing.JTextField txtDesPro;
    private javax.swing.JTextField txtDireccionProveedor;
    private javax.swing.JTextField txtDirecionCliente;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtNombrePersonal;
    private javax.swing.JTextField txtNombreProducto;
    private javax.swing.JTextField txtNombreproveedor;
    private javax.swing.JTextField txtPrecioPro;
    private javax.swing.JTextField txtTelefonoCliente;
    private javax.swing.JTextField txtTelefonoProveedor;
    // End of variables declaration//GEN-END:variables
       
}
